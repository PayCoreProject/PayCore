<?xml version="1.0" ?><!DOCTYPE TS><TS language="de" version="2.0">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Rechts-Klick um Adresse oder Bezeichnung zu bearbeiten</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Eine neue Adresse erstellen</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Neu</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Ausgewählte Adresse in die Zwischenablage kopieren</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopieren</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Ausgewählte Adresse aus der Liste entfernen</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Löschen</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Daten der aktuellen Ansicht in eine Datei exportieren</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportieren</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Wählen Sie die Adresse aus, an die Sie PCR überweisen möchten</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Wählen Sie die Adresse aus, über die Sie PCR empfangen wollen</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>&amp;Auswählen</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Zahlungsadressen</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Empfangsadressen</translation>
    </message>
    <message>
        <source>These are your PCR addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Dies sind ihre PCR-Adressen zum Tätigen von Überweisungen. Bitte prüfen Sie den Betrag und die Empfangsadresse, bevor Sie PCR überweisen.</translation>
    </message>
    <message>
        <source>These are your PCR addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Dies sind ihre PCR-Adressen zum Empfangen von Zahlungen. Es wird empfohlen für jede Transaktion eine neue Empfangsadresse zu verwenden.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Adresse kopieren</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>&amp;Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Editieren</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Adressliste exportieren</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommagetrennte-Datei (*.csv)</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Exportieren fehlgeschlagen</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>Beim Speichern der Adressliste nach %1 ist ein Fehler aufgetreten. Bitte noch einmal versuchen</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Passphrasendialog</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Passphrase eingeben</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Neue Passphrase</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Neue Passphrase wiederholen</translation>
    </message>
    <message>
        <source>Serves to disable the trivial sendmoney when OS account compromised. Provides no real security.</source>
        <translation>Verhindert das einfache Überweisen von Geld, falls das Systemkonto kompromittiert wurde. Bietet keine wirkliche Sicherheit.</translation>
    </message>
    <message>
        <source>For anonymization and staking only</source>
        <translation>Nur zur Anonymisierung</translation>
    </message>
    <message>
        <source>Enter the new passphrase to the wallet.&lt;br/&gt;Please use a passphrase of &lt;b&gt;ten or more random characters&lt;/b&gt;, or &lt;b&gt;eight or more words&lt;/b&gt;.</source>
        <translation>Geben Sie die neue Passphrase für die Wallet ein.&lt;br&gt;Bitte benutzen Sie eine Passphrase bestehend aus &lt;b&gt;10 oder mehr zufälligen Zeichen&lt;/b&gt; oder &lt;b&gt;8 oder mehr Wörtern&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Wallet verschlüsseln</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Dieser Vorgang benötigt ihre Passphrase, um die Wallet zu entsperren.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Wallet entsperren</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Dieser Vorgang benötigt ihre Passphrase, um die Wallet zu entschlüsseln.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Wallet entschlüsseln</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Passphrase ändern</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Geben Sie die alte und neue Wallet-Passphrase ein.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Wallet-Verschlüsselung bestätigen</translation>
    </message>
    <message>
        <source>Warning: If you encrypt your wallet and lose your passphrase, you will &lt;b&gt;LOSE ALL OF YOUR DNET&lt;/b&gt;!</source>
        <translation>Warnung: Wenn Sie ihre Wallet verschlüsseln und ihre Passphrase verlieren werden Sie &lt;b&gt;alle ihre PCR verlieren&lt;/b&gt;!</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Sind Sie sich sicher, dass Sie ihre Wallet verschlüsseln möchten?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Wallet verschlüsselt</translation>
    </message>
    <message>
        <source>PCR will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your capracoins from being stolen by malware infecting your computer.</source>
        <translation>PCR wird jetzt beendet, um den Verschlüsselungsprozess abzuschließen. Bitte beachten Sie, dass die Wallet-Verschlüsselung nicht vollständig vor Diebstahl ihrer PCR durch Schadsoftware schützt, die ihren Computer befällt.</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>WICHTIG: Alle vorherigen Wallet-Sicherungen sollten durch die neu erzeugte, verschlüsselte Wallet ersetzt werden. Aus Sicherheitsgründen werden vorherige Sicherungen der unverschlüsselten Wallet nutzlos, sobald Sie die neue, verschlüsselte Wallet verwenden.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Wallet-Verschlüsselung fehlgeschlagen</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Die Wallet-Verschlüsselung ist aufgrund eines internen Fehlers fehlgeschlagen. Ihre Wallet wurde nicht verschlüsselt.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Die eingegebenen Passphrasen stimmen nicht überein.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Wallet-Entsperrung fehlgeschlagen</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Die eingegebene Passphrase zur Wallet-Entschlüsselung war nicht korrekt.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Wallet-Entschlüsselung fehlgeschlagen</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Die Wallet-Passphrase wurde erfolgreich geändert.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Warnung: Die Feststelltaste ist aktiviert!</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Paycore Core</source>
        <translation>Paycore Core</translation>
    </message>
    <message>
        <source>Wallet</source>
        <translation>Wallet</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Knoten</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Übersicht</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Allgemeine Wallet-Übersicht anzeigen</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Überweisen</translation>
    </message>
    <message>
        <source>Send coins to a PCR address</source>
        <translation>PCR an eine PCR-Adresse überweisen</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Empfangen</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and capracoin: URIs)</source>
        <translation>Zahlungen anfordern (erzeugt QR-Codes und "capracoin:"-URIs)</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transaktionen</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Transaktionsverlauf durchsehen</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Beenden</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <source>&amp;About Paycore Core</source>
        <translation>&amp;Über Paycore Core</translation>
    </message>
    <message>
        <source>Show information about Paycore Core</source>
        <translation>Informationen über Paycore Core anzeigen</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Über &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Informationen über Qt anzeigen</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Konfiguration...</translation>
    </message>
    <message>
        <source>Modify configuration options for PCR</source>
        <translation>Die Konfiguration des Clients bearbeiten</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Anzeigen / Verstecken</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Das Hauptfenster anzeigen oder verstecken</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>Wallet &amp;verschlüsseln...</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Verschlüsselt die zu ihrer Wallet gehörenden privaten Schlüssel</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>Wallet &amp;sichern...</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Eine Wallet-Sicherungskopie erstellen und abspeichern</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>Passphrase &amp;ändern...</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Ändert die Passphrase, die für die Wallet-Verschlüsselung benutzt wird</translation>
    </message>
    <message>
        <source>&amp;Unlock Wallet...</source>
        <translation>Wallet &amp;entsperren</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Wallet entsperren</translation>
    </message>
    <message>
        <source>&amp;Lock Wallet</source>
        <translation>Wallet &amp;sperren</translation>
    </message>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Nachricht s&amp;ignieren...</translation>
    </message>
    <message>
        <source>Sign messages with your PCR addresses to prove you own them</source>
        <translation>Nachrichten signieren, um den Besitz ihrer PCR-Adressen zu beweisen</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>Nachricht &amp;verifizieren...</translation>
    </message>
    <message>
        <source>Verify messages to ensure they were signed with specified PCR addresses</source>
        <translation>Nachrichten verifizieren, um sicherzustellen, dass diese mit den angegebenen PCR-Adressen signiert wurden</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <source>Show diagnostic information</source>
        <translation>Diagnoseinformation anzeigen</translation>
    </message>
    <message>
        <source>&amp;Debug console</source>
        <translation>&amp;Debugkonsole</translation>
    </message>
    <message>
        <source>Open debugging console</source>
        <translation>Debugkonsole öffnen</translation>
    </message>
    <message>
        <source>&amp;Network Monitor</source>
        <translation>&amp;Netzwerkmonitor</translation>
    </message>
    <message>
        <source>Show network monitor</source>
        <translation>Netzwerkmonitor anzeigen</translation>
    </message>
    <message>
        <source>&amp;Peers list</source>
        <translation>&amp;Gegenstellen-Liste</translation>
    </message>
    <message>
        <source>Show peers info</source>
        <translation>Informationen zu Gegenstellen anzeigen</translation>
    </message>
    <message>
        <source>Wallet &amp;Repair</source>
        <translation>Wallet-&amp;Reparatur</translation>
    </message>
    <message>
        <source>Show wallet repair options</source>
        <translation>Optionen zur Wallet-Reparatur anzeigen</translation>
    </message>
    <message>
        <source>Open &amp;Configuration File</source>
        <translation>&amp;Konfigurationsdatei öffnen</translation>
    </message>
    <message>
        <source>Open configuration file</source>
        <translation>Konfigurationsdatei öffnen</translation>
    </message>
    <message>
        <source>Show Automatic &amp;Backups</source>
        <translation>Automatische &amp;Sicherheitskopien anzeigen</translation>
    </message>
    <message>
        <source>Show automatically created wallet backups</source>
        <translation>Automatisch erzeugte Wallet-Sicherheitskopien anzeigen</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Zahlungsadressen...</translation>
    </message>
    <message>
        <source>Show the list of used sending addresses and labels</source>
        <translation>Liste verwendeter Zahlungsadressen und Bezeichnungen anzeigen</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Empfangsadressen...</translation>
    </message>
    <message>
        <source>Show the list of used receiving addresses and labels</source>
        <translation>Liste verwendeter Empfangsadressen und Bezeichnungen anzeigen</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>&amp;URI öffnen...</translation>
    </message>
    <message>
        <source>Open a capracoin: URI or payment request</source>
        <translation>Eine "capracoin:"-URI oder Zahlungsanforderung öffnen</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Kommandozeilenoptionen</translation>
    </message>
    <message>
        <source>Paycore Core client</source>
        <translation>Paycore Core Client</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n blocks of transaction history.</source>
        <translation><numerusform>%n Block des Transaktionsverlaufs verarbeitet.</numerusform><numerusform>%n Blöcke des Transaktionsverlaufs verarbeitet.</numerusform></translation>
    </message>
    <message>
        <source>Synchronizing additional data: %p%</source>
        <translation>Synchronisiere zusätzliche Daten:  %p%</translation>
    </message>
    <message>
        <source>Show the Paycore Core help message to get a list with possible PCR command-line options</source>
        <translation>Zeige den "Paycore Core"-Hilfetext, um eine Liste mit möglichen Kommandozeilenoptionen zu erhalten</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Datei</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Einstellungen</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Werkzeuge</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Hilfe</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Registerkartenleiste</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to PCR network</source>
        <translation><numerusform>%n aktive Verbindung zum PCR-Netzwerk</numerusform><numerusform>%n aktive Verbindungen zum PCR-Netzwerk</numerusform></translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synchronisiere mit Netzwerk...</translation>
    </message>
    <message>
        <source>Importing blocks from disk...</source>
        <translation>Importiere Blöcke von Datenträger...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Reindiziere Blöcke auf Datenträger...</translation>
    </message>
    <message>
        <source>No block source available...</source>
        <translation>Keine Blockquelle verfügbar...</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Auf aktuellem Stand</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n Stunde</numerusform><numerusform>%n Stunden</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n Tag</numerusform><numerusform>%n Tage</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n Woche</numerusform><numerusform>%n Wochen</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 und %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n Jahr</numerusform><numerusform>%n Jahre</numerusform></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 im Rückstand</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Hole auf...</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Der letzte empfangene Block ist %1 alt.</translation>
    </message>
    <message>
        <source>Transactions after this will not yet be visible.</source>
        <translation>Transaktionen hiernach werden noch nicht angezeigt.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Hinweis</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Gesendete Transaktion</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Eingehende Transaktion</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Datum: %1
Betrag: %2
Typ: %3
Adresse: %4</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Wallet ist &lt;b&gt;verschlüsselt&lt;/b&gt; und aktuell &lt;b&gt;entsperrt&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt; for anonimization only</source>
        <translation>Wallet ist &lt;b&gt;verschlüsselt&lt;/b&gt; und aktuell nur zum Anonymisieren &lt;b&gt;entsperrt&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Wallet ist &lt;b&gt;verschlüsselt&lt;/b&gt; und aktuell &lt;b&gt;gesperrt&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Total: %1 (OBF compatible: %2 / Enabled: %3)</source>
        <translation>Gesamt: %1 (OBF kompatibel: %2 / Aktiviert: %3)</translation>
    </message>
    <message>
        <source>Network Alert</source>
        <translation>Netzwerkalarm</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Betrag:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorität:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Gebühr:</translation>
    </message>
    <message>
        <source>Coin Selection</source>
        <translation>"Coin Control"-Auswahl</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>"Dust"</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Abzüglich Gebühr:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Wechselgeld:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>Alles (de)selektieren</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Baumansicht</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Listenansicht</translation>
    </message>
    <message>
        <source>(1 locked)</source>
        <translation>(1 gesperrt)</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Empfangen über Bezeichner</translation>
    </message>
    <message>
        <source>Received with address</source>
        <translation>Empfangen über Adresse</translation>
    </message>
    <message>
        <source>OBF Rounds</source>
        <translation>OBF Runden</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Bestätigungen</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bestätigt</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Priorität</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Adresse kopieren</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Transaktions-ID kopieren</translation>
    </message>
    <message>
        <source>Lock unspent</source>
        <translation>Nicht ausgegebenen Betrag sperren</translation>
    </message>
    <message>
        <source>Unlock unspent</source>
        <translation>Nicht ausgegebenen Betrag entsperren</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Anzahl kopieren</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Abzüglich Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Byte kopieren</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Priorität kopieren</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>"Dust" Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Wechselgeld kopieren</translation>
    </message>
    <message>
        <source>Non-anonymized input selected. &lt;b&gt;Obfuscate will be disabled.&lt;/b&gt;&lt;br&gt;&lt;br&gt;If you still want to use Obfuscate, please deselect all non-nonymized inputs first and then check Obfuscate checkbox again.</source>
        <translation>Nicht-anonymisierter Input ausgewählt. &lt;b&gt;Obfuscate wird deaktiviert.&lt;/b&gt;&lt;br&gt;&lt;br&gt;Sollten Sie trotzdem Obfuscate verwenden wollen, müssen Sie zuerst alle nicht-anonymisierten Inputs entmarkieren und  das Ankreuzfeld "Obfuscate" erneut auswählen.</translation>
    </message>
    <message>
        <source>highest</source>
        <translation>am höchsten</translation>
    </message>
    <message>
        <source>higher</source>
        <translation>höher</translation>
    </message>
    <message>
        <source>high</source>
        <translation>hoch</translation>
    </message>
    <message>
        <source>medium-high</source>
        <translation>mittel-hoch</translation>
    </message>
    <message>
        <source>Can vary +/- %1 duff(s) per input.</source>
        <translation>Kann um +/- %1 duff(s) pro Eingabe variieren.</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>k.A.</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>mittel</translation>
    </message>
    <message>
        <source>low-medium</source>
        <translation>niedrig-mittel</translation>
    </message>
    <message>
        <source>low</source>
        <translation>niedrig</translation>
    </message>
    <message>
        <source>lower</source>
        <translation>niedriger</translation>
    </message>
    <message>
        <source>lowest</source>
        <translation>am niedrigsten</translation>
    </message>
    <message>
        <source>(%1 locked)</source>
        <translation>(%1 gesperrt)</translation>
    </message>
    <message>
        <source>none</source>
        <translation>keine</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>ja</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nein</translation>
    </message>
    <message>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation>Diese Bezeichnung wird rot, wenn die Transaktion größer als 1000 Byte ist.</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation>Das bedeutet, dass eine Gebühr von mindestens %1 pro kB erforderlich ist.</translation>
    </message>
    <message>
        <source>Can vary +/- 1 byte per input.</source>
        <translation>Kann um +/- 1 Byte pro Eingabe variieren.</translation>
    </message>
    <message>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation>Transaktionen mit höherer Priorität haben eine größere Chance in einen Block aufgenommen zu werden.</translation>
    </message>
    <message>
        <source>This label turns red, if the priority is smaller than "medium".</source>
        <translation>Diese Bezeichnung wird rot, wenn die Priorität niedriger als "mittel" ist.</translation>
    </message>
    <message>
        <source>This label turns red, if any recipient receives an amount smaller than %1.</source>
        <translation>Diese Bezeichnung wird rot, wenn irgendein Empfänger einen Betrag kleiner als %1 erhält.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>Wechselgeld von %1 (%2)</translation>
    </message>
    <message>
        <source>(change)</source>
        <translation>(Wechselgeld)</translation>
    </message>
</context>
<context>
    <name>ObfuscateConfig</name>
    <message>
        <source>Configure Obfuscate</source>
        <translation>Obfuscate konfigurieren</translation>
    </message>
    <message>
        <source>Basic Privacy</source>
        <translation>Einfacher Datenschutz</translation>
    </message>
    <message>
        <source>High Privacy</source>
        <translation>Hoher Datenschutz</translation>
    </message>
    <message>
        <source>Maximum Privacy</source>
        <translation>Maximaler Datenschutz</translation>
    </message>
    <message>
        <source>Please select a privacy level.</source>
        <translation>Bitten wählen Sie eine Datenschutz-Stufe.</translation>
    </message>
    <message>
        <source>Use 2 separate masternodes to mix funds up to 1000 DNET</source>
        <translation>Benutze 2 separate Masternodes um bis zu 1000 DNET zu mixen</translation>
    </message>
    <message>
        <source>Use 8 separate masternodes to mix funds up to 1000 DNET</source>
        <translation>Benutze 8 separate Masternodes um bis zu 1000 DNET zu mixen</translation>
    </message>
    <message>
        <source>Use 16 separate masternodes</source>
        <translation>Benutze 16 separate Masternodes</translation>
    </message>
    <message>
        <source>This option is the quickest and will cost about ~0.025 DNET to anonymize 1000 DNET</source>
        <translation>Diese Option ist am Schnellsten und kostet ungefähr 0,025 DNET, um 1000 DNET zu anonymisieren</translation>
    </message>
    <message>
        <source>This option is moderately fast and will cost about 0.05 DNET to anonymize 1000 DNET</source>
        <translation>Diese Option ist einigermaßen schnell und kostet ungefähr 0,05 DNET, um 1000 DNET zu anonymisieren</translation>
    </message>
    <message>
        <source>0.1 DNET per 1000 DNET you anonymize.</source>
        <translation>0,1 DNET pro 1000 zu anonymisierende PCR.</translation>
    </message>
    <message>
        <source>This is the slowest and most secure option. Using maximum anonymity will cost</source>
        <translation>Dies ist die langsamste und sicherste Option. Maximale Anonymität kostet</translation>
    </message>
    <message>
        <source>Obfuscate Configuration</source>
        <translation>Obfuscate-Konfiguration</translation>
    </message>
    <message>
        <source>Obfuscate was successfully set to basic (%1 and 2 rounds). You can change this at any time by opening PCR's configuration screen.</source>
        <translation>Obfuscate wurde erfolgreich auf einfachen Datenschutz (%1 und 2 Runden) gesetzt. Sie können dies jederzeit im Konfigurationsfenster von PCR ändern.</translation>
    </message>
    <message>
        <source>Obfuscate was successfully set to high (%1 and 8 rounds). You can change this at any time by opening PCR's configuration screen.</source>
        <translation>Obfuscate wurde erfolgreich auf hohen Datenschutz (%1 und 8 Runden) gesetzt. Sie können dies jederzeit im Konfigurationsfenster von PCR ändern.</translation>
    </message>
    <message>
        <source>Obfuscate was successfully set to maximum (%1 and 16 rounds). You can change this at any time by opening PCR's configuration screen.</source>
        <translation>Obfuscate wurde erfolgreich auf maximalen Datenschutz (%1 und 16 Runden) gesetzt. Sie können dies jederzeit im Konfigurationsfenster von PCR ändern.</translation>
    </message>
</context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Adresse bearbeiten</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Bezeichnung</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Bezeichnung, die dem Adresslisteneintrag zugeordnet ist.</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adresse</translation>
    </message>
    <message>
        <source>The address associated with this address list entry. This can only be modified for sending addresses.</source>
        <translation>Adresse, die dem Adresslisteneintrag zugeordnet ist. Diese kann nur bei Zahlungsadressen verändert werden.</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Neue Empfangsadresse</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Neue Zahlungsadresse</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Empfangsadresse bearbeiten</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Zahlungsadresse bearbeiten</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid PCR address.</source>
        <translation>Die eingegebene Adresse "%1" ist keine gültige PCR-Adresse.</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>Die eingegebene Adresse "%1" befindet sich bereits im Adressbuch.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Wallet konnte nicht entsperrt werden.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Erzeugung eines neuen Schlüssels fehlgeschlagen.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Es wird ein neues Datenverzeichnis angelegt.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Verzeichnis existiert bereits. Fügen Sie %1 an, wenn Sie beabsichtigen hier ein neues Verzeichnis anzulegen.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Pfad existiert bereits und ist kein Verzeichnis.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Datenverzeichnis kann hier nicht angelegt werden.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Paycore Core</source>
        <translation>Paycore Core</translation>
    </message>
    <message>
        <source>version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-Bit)</translation>
    </message>
    <message>
        <source>About Paycore Core</source>
        <translation>Über Paycore Core</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Kommandozeilenoptionen</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Benutzung:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>Kommandozeilenoptionen</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>UI-Optionen</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation>Datenverzeichnis beim Starten auswählen (Standard: 0)</translation>
    </message>
    <message>
        <source>Set language, for example "de_DE" (default: system locale)</source>
        <translation>Sprache festlegen, z.B. "de_DE" (Standard: Systemstandard)</translation>
    </message>
    <message>
        <source>Start minimized</source>
        <translation>Minimiert starten</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>SSL-Wurzelzertifikate für Zahlungsanforderungen festlegen (Standard: Systemstandard)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Startbildschirm beim Starten anzeigen (Standard: 1)</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Willkommen</translation>
    </message>
    <message>
        <source>Welcome to Paycore Core.</source>
        <translation>Willkommen zu Paycore Core.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where Paycore Core will store its data.</source>
        <translation>Da dies das erste Mal ist, dass Sie Paycore Core starten, legen Sie jetzt bitte fest, an welchem Ort die Daten gespeichert werden sollen.</translation>
    </message>
    <message>
        <source>Paycore Core will download and store a copy of the PCR block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>Paycore Core wird jetzt die Blockchain laden und lokal speichern. Dafür sind mindestens %1GB freier Speicherplatz erforderlich. Der Speicherbedarf wird mit der Zeit anwachsen. Das Wallet wird ebenfalls in diesem Verzeichnis gespeichert.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Standard-Datenverzeichnis verwenden</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Ein benutzerdefiniertes Datenverzeichnis verwenden:</translation>
    </message>
    <message>
        <source>Paycore Core</source>
        <translation>Paycore Core</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation>Fehler: Angegebenes Datenverzeichnis "%1" kann nicht angelegt werden.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>%1 GB of free space available</source>
        <translation>%1 GB freier Speicherplatz verfügbar</translation>
    </message>
    <message>
        <source>(of %1 GB needed)</source>
        <translation>(von benötigten %1 GB)</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>URI öffnen</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Zahlungsanforderung über URI oder aus Datei öffnen</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Zahlungsanforderungsdatei auswählen</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>Zu öffnende Zahlungsanforderungsdatei auswählen</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Konfiguration</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Allgemein</translation>
    </message>
    <message>
        <source>Automatically start PCR after logging in to the system.</source>
        <translation>PCR nach der Anmeldung am System automatisch starten.</translation>
    </message>
    <message>
        <source>&amp;Start PCR on system login</source>
        <translation>&amp;Starte PCR automatisch nach Systemanmeldung</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Größe des &amp;Datenbankcaches</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Anzahl an Skript-&amp;Verifizierungs-Threads</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = automatisch, &lt;0 = so viele Kerne frei lassen)</translation>
    </message>
    <message>
        <source>Obfuscate rounds to use</source>
        <translation>Obfuscate Runden</translation>
    </message>
    <message>
        <source>This amount acts as a threshold to turn off Obfuscate once it's reached.</source>
        <translation>Beim Erreichen dieses Betrages wird Obfuscate ausgeschaltet.</translation>
    </message>
    <message>
        <source>Amount of PCR to keep anonymized</source>
        <translation>Anzahl anonymisierter PCR</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>W&amp;allet</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction&lt;br/&gt;cannot be used until that transaction has at least one confirmation.&lt;br/&gt;This also affects how your balance is computed.</source>
        <translation>Wenn Sie das Ausgeben von unbestätigtem Wechselgeld deaktivieren, kann das Wechselgeld einer &lt;br/&gt; Transaktion nicht verwendet werden, bis es mindestens eine Bestätigung erhalten hat.&lt;br/&gt;Dies wirkt sich auf die Berechnung des Kontostands aus.</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>Eingehende Verbindungen annehmen</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>Eingehende Verbindungen erlauben</translation>
    </message>
    <message>
        <source>Connect to the PCR network through a SOCKS5 proxy.</source>
        <translation>Über einen SOCKS5-Proxy mit dem PCR-Netzwerk verbinden.</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>Über einen SOCKS5-Proxy &amp;verbinden (Standardproxy):</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Erweiterte Wallet-Optionen</translation>
    </message>
    <message>
        <source>This setting determines the amount of individual masternodes that an input will be anonymized through.&lt;br/&gt;More rounds of anonymization gives a higher degree of privacy, but also costs more in fees.</source>
        <translation>Diese Einstellung setzt fest, durch wie viele Masternodes ein Input anonymisiert wird. &lt;br/&gt; Eine höhere Anzahl bedeutet höhere Anonymität, verursacht allerdings auch höhere Gebühren.</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Legt fest, ob die "Coin Control"-Funktionen angezeigt werden.</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>"&amp;Coin Control"-Funktionen aktivieren</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;Unbestätigtes Wechselgeld darf ausgegeben werden</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Netzwerk</translation>
    </message>
    <message>
        <source>Automatically open the PCR client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Automatisch den PCR-Clientport auf dem Router öffnen. Dies funktioniert nur, wenn Ihr Router UPnP unterstützt und dies aktiviert ist.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Portweiterleitung via &amp;UPnP</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>Proxy-&amp;IP:</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>IP-Adresse des Proxies (z.B. IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Port des Proxies (z.B. 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Programmfenster</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>Nur ein Symbol im Infobereich anzeigen, nachdem das Programmfenster minimiert wurde.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>In den Infobereich anstatt in die Taskleiste &amp;minimieren</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Minimiert die Anwendung anstatt sie zu beenden wenn das Fenster geschlossen wird. Wenn dies aktiviert ist, müssen Sie das Programm über "Beenden" im Menü schließen.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>Beim Schließen m&amp;inimieren</translation>
    </message>
    <message>
        <source>&amp;Display</source>
        <translation>Anzei&amp;ge</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Sprache der Benutzeroberfläche:</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting PCR.</source>
        <translation>Legt die Sprache der Benutzeroberfläche fest. Diese Einstellung wird erst nach einem Neustart von PCR aktiv.</translation>
    </message>
    <message>
        <source>Language missing or translation incomplete? Help contributing translations here:
https://www.transifex.com/capracoin-crypto/capracoin-wallet-translations/</source>
        <translation>Fehlt eine Sprache oder ist unvollständig übersetzt? Hier können Sie helfen:
https://www.transifex.com/capracoin-crypto/capracoin-wallet-translations/</translation>
    </message>
    <message>
        <source>User Interface Theme:</source>
        <translation>Design/Thema der Benutzeroberfläche:</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>&amp;Einheit der Beträge:</translation>
    </message>
    <message>
        <source>Choose the default subdivision unit to show in the interface and when sending coins.</source>
        <translation>Wählen Sie die standardmäßige Untereinheit, die in der Benutzeroberfläche und beim Überweisen von PCR angezeigt werden soll.</translation>
    </message>
    <message>
        <source>Decimal digits</source>
        <translation>Dezimalziffern</translation>
    </message>
    <message>
        <source>Third party URLs (e.g. a block explorer) that appear in the transactions tab as context menu items. %s in the URL is replaced by transaction hash. Multiple URLs are separated by vertical bar |.</source>
        <translation>Externe URLs (z.B. ein Block-Explorer), die im Kontextmenü des Transaktionsverlaufs eingefügt werden. In der URL wird %s durch den Transaktionshash ersetzt. Bei Angabe mehrerer URLs müssen diese durch "|" voneinander getrennt werden.</translation>
    </message>
    <message>
        <source>Third party transaction URLs</source>
        <translation>Externe Transaktions-URLs</translation>
    </message>
    <message>
        <source>Active command-line options that override above options:</source>
        <translation>Aktive Kommandozeilenoptionen, die obige Konfiguration überschreiben:</translation>
    </message>
    <message>
        <source>Reset all client options to default.</source>
        <translation>Setzt die Clientkonfiguration auf Standardwerte zurück.</translation>
    </message>
    <message>
        <source>&amp;Reset Options</source>
        <translation>Konfiguration &amp;zurücksetzen</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>A&amp;bbrechen</translation>
    </message>
    <message>
        <source>default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <source>none</source>
        <translation>keine</translation>
    </message>
    <message>
        <source>Confirm options reset</source>
        <translation>Zurücksetzen der Konfiguration bestätigen</translation>
    </message>
    <message>
        <source>Client restart required to activate changes.</source>
        <translation>Clientneustart nötig, um die Änderungen zu aktivieren.</translation>
    </message>
    <message>
        <source>Client will be shutdown, do you want to proceed?</source>
        <translation>Client wird beendet, wollen Sie fortfahren?</translation>
    </message>
    <message>
        <source>This change would require a client restart.</source>
        <translation>Diese Änderung würde einen Clientneustart benötigen.</translation>
    </message>
    <message>
        <source>The supplied proxy address is invalid.</source>
        <translation>Die eingegebene Proxyadresse ist ungültig.</translation>
    </message>
</context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <source>The displayed information may be out of date. Your wallet automatically synchronizes with the PCR network after a connection is established, but this process has not completed yet.</source>
        <translation>Die angezeigten Informationen sind möglicherweise nicht mehr aktuell. Ihre Wallet wird automatisch synchronisiert, nachdem eine Verbindung zum PCR-Netzwerk hergestellt wurde. Dieser Prozess ist jedoch derzeit noch nicht abgeschlossen.</translation>
    </message>
    <message>
        <source>Available:</source>
        <translation>Verfügbar:</translation>
    </message>
    <message>
        <source>Your current spendable balance</source>
        <translation>Ihr aktuell verfügbarer Kontostand</translation>
    </message>
    <message>
        <source>Pending:</source>
        <translation>Ausstehend:</translation>
    </message>
    <message>
        <source>Total of transactions that have yet to be confirmed, and do not yet count toward the spendable balance</source>
        <translation>Betrag aus unbestätigten Transaktionen, der noch nicht im aktuell verfügbaren Kontostand enthalten ist</translation>
    </message>
    <message>
        <source>Immature:</source>
        <translation>Unreif:</translation>
    </message>
    <message>
        <source>Staked or masternode rewards that has not yet matured</source>
        <translation>Erarbeiteter Betrag der noch nicht gereift ist</translation>
    </message>
    <message>
        <source>Balances</source>
        <translation>Kontostände</translation>
    </message>
    <message>
        <source>Unconfirmed transactions to watch-only addresses</source>
        <translation>Unbestätigte Transaktionen  zu beobachteten Adressen</translation>
    </message>
    <message>
        <source>Staked or masternode rewards in watch-only addresses that has not yet matured</source>
        <translation>Erarbeiteter Betrag der beobachteten Adressen der noch nicht gereift ist</translation>
    </message>
    <message>
        <source>Total:</source>
        <translation>Gesamtbetrag:</translation>
    </message>
    <message>
        <source>Your current total balance</source>
        <translation>Aktueller Gesamtbetrag aus obigen Kategorien</translation>
    </message>
    <message>
        <source>Current total balance in watch-only addresses</source>
        <translation>Kontostand der beobachteten Adressen</translation>
    </message>
    <message>
        <source>Watch-only:</source>
        <translation>Beobachtet:</translation>
    </message>
    <message>
        <source>Your current balance in watch-only addresses</source>
        <translation>Aktueller Kontostand der beobachteten Adressen</translation>
    </message>
    <message>
        <source>Spendable:</source>
        <translation>Verfügbar:</translation>
    </message>
    <message>
        <source>Status:</source>
        <translation>Status:</translation>
    </message>
    <message>
        <source>Enabled/Disabled</source>
        <translation>Aktiviert/Deaktiviert</translation>
    </message>
    <message>
        <source>Completion:</source>
        <translation>Vollendet:</translation>
    </message>
    <message>
        <source>Obfuscate Balance:</source>
        <translation>Obfuscate Kontostand:</translation>
    </message>
    <message>
        <source>Amount and Rounds:</source>
        <translation>Betrag und Runden:</translation>
    </message>
    <message>
        <source>0 DNET / 0 Rounds</source>
        <translation>0 DNET / 0 Runden</translation>
    </message>
    <message>
        <source>Submitted Denom:</source>
        <translation>Stückelung des Betrages:</translation>
    </message>
    <message>
        <source>n/a</source>
        <translation>k.A.</translation>
    </message>
    <message>
        <source>Obfuscate</source>
        <translation>Obfuscate</translation>
    </message>
    <message>
        <source>Recent transactions</source>
        <translation>Letzte Transaktionen</translation>
    </message>
    <message>
        <source>Start/Stop Mixing</source>
        <translation>Starte/Stoppe das Mixen</translation>
    </message>
    <message>
        <source>The denominations you submitted to the Masternode.&lt;br&gt;To mix, other users must submit the exact same denominations.</source>
        <translation>Die gestückelten Beträge, die Sie zu dem Masternode gesendet haben.&lt;br&gt; Zum Erfolgreichen Mixen müssen andere Benutzer exakt gleich gestückelte Beträge senden.</translation>
    </message>
    <message>
        <source>(Last Message)</source>
        <translation>(Letzte Nachricht)</translation>
    </message>
    <message>
        <source>Try to manually submit a Obfuscate request.</source>
        <translation>Versuche eine Obfuscateanfrage manuell abzusetzen.</translation>
    </message>
    <message>
        <source>Try Mix</source>
        <translation>Versuche zu Mixen</translation>
    </message>
    <message>
        <source>Reset the current status of Obfuscate (can interrupt Obfuscate if it's in the process of Mixing, which can cost you money!)</source>
        <translation>Aktuellen Obfuscate Status zurücksetzen (wenn der Prozess des Mixens bereits begonnen hat kann es passieren, dass Obfuscate unterbrochen wird. Bereits gezahlte Gebühren werden einbehalten!) </translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <source>out of sync</source>
        <translation>nicht synchron</translation>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Deaktiviert</translation>
    </message>
    <message>
        <source>Start Obfuscate Mixing</source>
        <translation>Starte Obfuscate Mixen</translation>
    </message>
    <message>
        <source>Stop Obfuscate Mixing</source>
        <translation>Stoppe Obfuscate Mixen</translation>
    </message>
    <message>
        <source>No inputs detected</source>
        <translation>Keine Inputs gefunden</translation>
    </message>
    <message numerus="yes">
        <source>%n Rounds</source>
        <translation><numerusform>%n Runde</numerusform><numerusform>%n Runden</numerusform></translation>
    </message>
    <message>
        <source>Not enough compatible inputs to anonymize &lt;span style='color:red;'&gt;%1&lt;/span&gt;,&lt;br&gt;will anonymize &lt;span style='color:red;'&gt;%2&lt;/span&gt; instead</source>
        <translation>Nicht genug kompatible Inputs zum Anonymisieren von &lt;span style='color:red;'&gt;%1&lt;/span&gt; gefunden,&lt;br/&gt;&lt;span style='color:red;'&gt;%2&lt;/span&gt; wird stattdessen anonymisiert</translation>
    </message>
    <message>
        <source>Overall progress</source>
        <translation>Fortschritt</translation>
    </message>
    <message>
        <source>Denominated</source>
        <translation>Gestückelt</translation>
    </message>
    <message>
        <source>Anonymized</source>
        <translation>Anonymisiert</translation>
    </message>
    <message numerus="yes">
        <source>Denominated inputs have %5 of %n rounds on average</source>
        <translation><numerusform>Gestückelte Inputs haben im Durchschnitt %5 von %n Runde</numerusform><numerusform>Gestückelte Inputs haben im Durchschnitt %5 von %n Runden</numerusform></translation>
    </message>
    <message>
        <source>Found enough compatible inputs to anonymize %1</source>
        <translation>Genug kompatible Inputs zum Anonymisieren von %1 gefunden</translation>
    </message>
    <message>
        <source>Mixed</source>
        <translation>Gemixt</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Aktiviert</translation>
    </message>
    <message>
        <source>Last Obfuscate message:
</source>
        <translation>Letzter Obfuscate Status:
</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>k.A.</translation>
    </message>
    <message>
        <source>Obfuscate was successfully reset.</source>
        <translation>Obfuscate wurde erfolgreich zurückgesetzt.</translation>
    </message>
    <message>
        <source>If you don't want to see internal Obfuscate fees/transactions select "Most Common" as Type on the "Transactions" tab.</source>
        <translation>Wenn Sie keine internen Obfuscate-Gebühren oder -Transaktionen sehen wollen wählen Sie "Gängigste" als Typ auf der "Transaktionen" Karteikarte.</translation>
    </message>
    <message>
        <source>Obfuscate requires at least %1 to use.</source>
        <translation>Zur Benutzung von Obfuscate benötigt man mindestens %1</translation>
    </message>
    <message>
        <source>Wallet is locked and user declined to unlock. Disabling Obfuscate.</source>
        <translation>Das Wallet ist gesperrt und der Benutzer hat abgelehnt, es zu entsperren. Obfuscate wird deaktiviert.</translation>
    </message>
</context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment request error</source>
        <translation>Fehlerhafte Zahlungsanforderung</translation>
    </message>
    <message>
        <source>Cannot start capracoin: click-to-pay handler</source>
        <translation>PCR kann nicht gestartet werden: click-to-pay handler</translation>
    </message>
    <message>
        <source>URI handling</source>
        <translation>URI-Verarbeitung</translation>
    </message>
    <message>
        <source>Payment request fetch URL is invalid: %1</source>
        <translation>Abruf-URL der Zahlungsanforderung ist ungültig: %1</translation>
    </message>
    <message>
        <source>Payment request file handling</source>
        <translation>Zahlungsanforderungsdatei-Verarbeitung</translation>
    </message>
    <message>
        <source>Invalid payment address %1</source>
        <translation>Ungültige Zahlungsadresse %1</translation>
    </message>
    <message>
        <source>URI cannot be parsed! This can be caused by an invalid PCR address or malformed URI parameters.</source>
        <translation>URI konnte nicht erfolgreich verarbeitet werden. Höchstwahrscheinlich ist dies entweder keine gültige PCR-Adresse oder die URI-Parameter sind falsch gesetzt. </translation>
    </message>
    <message>
        <source>Payment request file cannot be read! This can be caused by an invalid payment request file.</source>
        <translation>Zahlungsanforderungsdatei kann nicht gelesen werden! Dies kann durch eine ungültige Zahlungsanforderungsdatei verursacht werden.</translation>
    </message>
    <message>
        <source>Payment request rejected</source>
        <translation>Zahlungsanforderung abgelehnt</translation>
    </message>
    <message>
        <source>Payment request network doesn't match client network.</source>
        <translation>Netzwerk der Zahlungsanforderung passt nicht zum Client-Netzwerk.</translation>
    </message>
    <message>
        <source>Payment request has expired.</source>
        <translation>Zahlungsanforderung ist abgelaufen</translation>
    </message>
    <message>
        <source>Payment request is not initialized.</source>
        <translation>Zahlungsanforderung ist nicht initialisiert.</translation>
    </message>
    <message>
        <source>Unverified payment requests to custom payment scripts are unsupported.</source>
        <translation>Unverifizierte Zahlungsanforderungen an benutzerdefinierte Zahlungsskripte werden nicht unterstützt.</translation>
    </message>
    <message>
        <source>Requested payment amount of %1 is too small (considered dust).</source>
        <translation>Angeforderter Zahlungsbetrag in Höhe von %1 ist zu niedrig und wurde als "Dust" eingestuft.</translation>
    </message>
    <message>
        <source>Refund from %1</source>
        <translation>Rücküberweisung von %1</translation>
    </message>
    <message>
        <source>Payment request %1 is too large (%2 bytes, allowed %3 bytes).</source>
        <translation>Zahlungsanforderung %1 ist zu groß (%2 Bytes, erlaubt sind %3 Bytes).</translation>
    </message>
    <message>
        <source>Payment request DoS protection</source>
        <translation>Überlastungs-Schutz Zahlungsanforderung</translation>
    </message>
    <message>
        <source>Error communicating with %1: %2</source>
        <translation>Kommunikationsfehler mit %1: %2</translation>
    </message>
    <message>
        <source>Payment request cannot be parsed!</source>
        <translation>Zahlungsanforderung kann nicht analysiert werden!</translation>
    </message>
    <message>
        <source>Bad response from server %1</source>
        <translation>Fehlerhafte Antwort vom Server: %1</translation>
    </message>
    <message>
        <source>Network request error</source>
        <translation>fehlerhafte Netzwerkanfrage</translation>
    </message>
    <message>
        <source>Payment acknowledged</source>
        <translation>Zahlung bestätigt</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    <message>
        <source>Address/Hostname</source>
        <translation>Adresse/Rechnername</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Benutzerprogramm</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Ping-Antwort-Zeit</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Enter a PCR address (e.g. %1)</source>
        <translation>PCR-Adresse eingeben (z.B. %1)</translation>
    </message>
    <message>
        <source>%1 d</source>
        <translation>%1 T</translation>
    </message>
    <message>
        <source>%1 h</source>
        <translation>%1 St.</translation>
    </message>
    <message>
        <source>%1 m</source>
        <translation>%1 Min.</translation>
    </message>
    <message>
        <source>%1 s</source>
        <translation>%1  S</translation>
    </message>
    <message>
        <source>NETWORK</source>
        <translation>NETZWERK</translation>
    </message>
    <message>
        <source>UNKNOWN</source>
        <translation>UNBEKANNT</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Keine</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>k.A.</translation>
    </message>
    <message>
        <source>%1 ms</source>
        <translation>%1 Ms</translation>
    </message>
</context>
<context>
    <name>QRImageWidget</name>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Grafik &amp;speichern...</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>Grafik &amp;kopieren</translation>
    </message>
    <message>
        <source>Save QR Code</source>
        <translation>QR-Code speichern</translation>
    </message>
    <message>
        <source>PNG Image (*.png)</source>
        <translation>PNG-Grafik (*.png)</translation>
    </message>
</context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Tools window</source>
        <translation>Werkzeuge</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <source>Client name</source>
        <translation>Clientname</translation>
    </message>
    <message>
        <source>N/A</source>
        <translation>k.A.</translation>
    </message>
    <message>
        <source>Number of connections</source>
        <translation>Anzahl Verbindungen</translation>
    </message>
    <message>
        <source>Open the PCR debug log file from the current data directory. This can take a few seconds for large log files.</source>
        <translation>Öffnet die PCR-Debugprotokolldatei aus dem aktuellen Datenverzeichnis. Dies kann bei großen Protokolldateien einige Sekunden dauern.</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Öffnen</translation>
    </message>
    <message>
        <source>Startup time</source>
        <translation>Startzeit</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Netzwerk</translation>
    </message>
    <message>
        <source>Last block time</source>
        <translation>Letzte Blockzeit</translation>
    </message>
    <message>
        <source>Debug log file</source>
        <translation>Debugprotokolldatei</translation>
    </message>
    <message>
        <source>Using OpenSSL version</source>
        <translation>Verwendete OpenSSL-Version</translation>
    </message>
    <message>
        <source>Build date</source>
        <translation>Erstellungsdatum</translation>
    </message>
    <message>
        <source>Current number of blocks</source>
        <translation>Aktuelle Anzahl Blöcke</translation>
    </message>
    <message>
        <source>Client version</source>
        <translation>Clientversion</translation>
    </message>
    <message>
        <source>Using BerkeleyDB version</source>
        <translation>Verwendete BerkeleyDB-Version</translation>
    </message>
    <message>
        <source>Block chain</source>
        <translation>Blockkette</translation>
    </message>
    <message>
        <source>Number of Masternodes</source>
        <translation>Anzahl Masternodes</translation>
    </message>
    <message>
        <source>&amp;Console</source>
        <translation>&amp;Konsole</translation>
    </message>
    <message>
        <source>Clear console</source>
        <translation>Konsole zurücksetzen</translation>
    </message>
    <message>
        <source>&amp;Network Traffic</source>
        <translation>&amp;Netzwerkauslastung</translation>
    </message>
    <message>
        <source>&amp;Clear</source>
        <translation>&amp;Zurücksetzen</translation>
    </message>
    <message>
        <source>Totals</source>
        <translation>Summen</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Empfangen</translation>
    </message>
    <message>
        <source>Sent</source>
        <translation>Überwiesen</translation>
    </message>
    <message>
        <source>&amp;Peers</source>
        <translation>&amp;Gegenstellen</translation>
    </message>
    <message>
        <source>Select a peer to view detailed information.</source>
        <translation>Gegenstelle auswählen, um Detailinformationen zu sehen.</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Richtung</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Version</source>
        <translation>Benutzerprogramm</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Dienste</translation>
    </message>
    <message>
        <source>Starting Height</source>
        <translation>Ausgangs-Blocknummer</translation>
    </message>
    <message>
        <source>Sync Height</source>
        <translation>Synchronisierte Blocknummer</translation>
    </message>
    <message>
        <source>Ban Score</source>
        <translation>Ausschluss-Punktzahl</translation>
    </message>
    <message>
        <source>Connection Time</source>
        <translation>Verbindungszeit</translation>
    </message>
    <message>
        <source>Last Send</source>
        <translation>Letzte Überweisung</translation>
    </message>
    <message>
        <source>Last Receive</source>
        <translation>Letzter Empfang</translation>
    </message>
    <message>
        <source>Bytes Sent</source>
        <translation>Bytes gesendet:</translation>
    </message>
    <message>
        <source>Bytes Received</source>
        <translation>Bytes empfangen</translation>
    </message>
    <message>
        <source>Ping Time</source>
        <translation>Ping-Antwort-Zeit</translation>
    </message>
    <message>
        <source>&amp;Wallet Repair</source>
        <translation>&amp;Wallet-Reparatur</translation>
    </message>
    <message>
        <source>Salvage wallet</source>
        <translation>Wallet Datenwiederherstellungen</translation>
    </message>
    <message>
        <source>Rescan blockchain files</source>
        <translation>Dateien der Blockkette erneut durchsuchen</translation>
    </message>
    <message>
        <source>Recover transactions 1</source>
        <translation>Transaktion wiederherstellen 1</translation>
    </message>
    <message>
        <source>Recover transactions 2</source>
        <translation>Transaktion wiederherstellen 2</translation>
    </message>
    <message>
        <source>Upgrade wallet format</source>
        <translation>Wallet-Format aktualisieren</translation>
    </message>
    <message>
        <source>The buttons below will restart the wallet with command-line options to repair the wallet, fix issues with corrupt blockhain files or missing/obsolete transactions.</source>
        <translation>Diese Buttons starten die Wallet mit Kommandozeilen-Parametern zur Reparatur von etwaigen  Fehlern.</translation>
    </message>
    <message>
        <source>-salvagewallet: Attempt to recover private keys from a corrupt wallet.dat.</source>
        <translation>-salvagewallet: versucht private Schlüssel aus einer beschädigten wallet.dat wiederherzustellen</translation>
    </message>
    <message>
        <source>-rescan: Rescan the block chain for missing wallet transactions.</source>
        <translation>-rescan: Blockkette erneut nach fehlenden Wallet-Transaktionen durchsuchen</translation>
    </message>
    <message>
        <source>-zapwallettxes=1: Recover transactions from blockchain (keep meta-data, e.g. account owner).</source>
        <translation>-zapwallettxes=1: Transaktion wiederherstellen (Metadaten, z.B. Kontoinhaber, behalten)</translation>
    </message>
    <message>
        <source>-zapwallettxes=2: Recover transactions from blockchain (drop meta-data).</source>
        <translation>-zapwallettxes=2: Transaktion wiederherstellen (Metadaten verwerfen)</translation>
    </message>
    <message>
        <source>-upgradewallet: Upgrade wallet to latest format on startup. (Note: this is NOT an update of the wallet itself!)</source>
        <translation>Wallet-Format aktualisieren. (dies ist KEINE Aktualisierung des Wallet)</translation>
    </message>
    <message>
        <source>Wallet repair options.</source>
        <translation>Optionen zur Wallet-Reparatur.</translation>
    </message>
    <message>
        <source>Rebuild index</source>
        <translation>Index neu aufbauen</translation>
    </message>
    <message>
        <source>-reindex: Rebuild block chain index from current blk000??.dat files.</source>
        <translation>-reindex: Blockkettenindex aus aktuellen Dateien blk000??.dat wieder aufbauen</translation>
    </message>
    <message>
        <source>In:</source>
        <translation>eingehend:</translation>
    </message>
    <message>
        <source>Out:</source>
        <translation>ausgehend:</translation>
    </message>
    <message>
        <source>Welcome to the PCR RPC console.</source>
        <translation>Willkommen in der PCR RPC-Console.</translation>
    </message>
    <message>
        <source>Use up and down arrows to navigate history, and &lt;b&gt;Ctrl-L&lt;/b&gt; to clear screen.</source>
        <translation>Pfeiltaste hoch und runter, um den Verlauf durchzublättern und &lt;b&gt;Strg-L&lt;/b&gt;, um die Konsole zurückzusetzen.</translation>
    </message>
    <message>
        <source>Type &lt;b&gt;help&lt;/b&gt; for an overview of available commands.</source>
        <translation>Bitte &lt;b&gt;help&lt;/b&gt; eingeben, um eine Übersicht verfügbarer Befehle zu erhalten.</translation>
    </message>
    <message>
        <source>%1 B</source>
        <translation>%1 B</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>via %1</source>
        <translation>über %1</translation>
    </message>
    <message>
        <source>never</source>
        <translation>niemals</translation>
    </message>
    <message>
        <source>Inbound</source>
        <translation>Eingehend</translation>
    </message>
    <message>
        <source>Outbound</source>
        <translation>Ausgehend</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Unbekannt</translation>
    </message>
    <message>
        <source>Fetching...</source>
        <translation>Am Abrufen...</translation>
    </message>
</context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>Reuse one of the previously used receiving addresses.&lt;br&gt;Reusing addresses has security and privacy issues.&lt;br&gt;Do not use this unless re-generating a payment request made before.</source>
        <translation>Eine der bereits verwendeten Empfangsadressen wiederverwenden.&lt;br&gt; Addressen wiederzuverwenden birgt Sicherheits- und Datenschutzrisiken.&lt;br&gt; Außer zum Neuerstellen einer bereits erzeugten Zahlungsanforderung sollten Sie dies nicht nutzen.</translation>
    </message>
    <message>
        <source>R&amp;euse an existing receiving address (not recommended)</source>
        <translation>Vorhandene Empfangsadresse &amp;wiederverwenden (nicht empfohlen)</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened. Note: The message will not be sent with the payment over the PCR network.</source>
        <translation>Eine optionale Nachricht, die an die Zahlungsanforderung angehängt wird. Sie wird angezeigt, wenn die Anforderung geöffnet wird. Hinweis: Diese Nachricht wird nicht mit der Zahlung über das PCR-Netzwerk gesendet.</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>&amp;Nachricht:</translation>
    </message>
    <message>
        <source>An optional label to associate with the new receiving address.</source>
        <translation>Eine optionale Bezeichnung, die der neuen Empfangsadresse zugeordnet wird.</translation>
    </message>
    <message>
        <source>An optional message to attach to the payment request, which will be displayed when the request is opened.&lt;br&gt;Note: The message will not be sent with the payment over the PCR network.</source>
        <translation>Eine optionale Nachricht, die an die Zahlungsanforderung angehängt wird. Sie wird angezeigt, wenn die Anforderung geöffnet wird.&lt;br&gt; Hinweis: Diese Nachricht wird nicht mit der Zahlung über das PCR-Netzwerk gesendet.</translation>
    </message>
    <message>
        <source>Use this form to request payments. All fields are &lt;b&gt;optional&lt;/b&gt;.</source>
        <translation>Verwenden Sie dieses Formular, um Zahlungen anzufordern. Alle Felder sind &lt;b&gt;optional&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Bezeichnung:</translation>
    </message>
    <message>
        <source>An optional amount to request. Leave this empty or zero to not request a specific amount.</source>
        <translation>Ein optional angeforderte Betrag. Lassen Sie dieses Feld leer oder setzen Sie es auf 0, um keinen spezifischen Betrag anzufordern.</translation>
    </message>
    <message>
        <source>&amp;Amount:</source>
        <translation>&amp;Betrag:</translation>
    </message>
    <message>
        <source>&amp;Request payment</source>
        <translation>&amp;Zahlung anfordern</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Alle Formularfelder zurücksetzen.</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <source>Requested payments history</source>
        <translation>Verlauf der angeforderten Zahlungen</translation>
    </message>
    <message>
        <source>Show the selected request (does the same as double clicking an entry)</source>
        <translation>Ausgewählte Zahlungsanforderungen anzeigen (entspricht einem Doppelklick auf einen Eintrag)</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Anzeigen</translation>
    </message>
    <message>
        <source>Remove the selected entries from the list</source>
        <translation>Ausgewählte Einträge aus der Liste entfernen</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>Copy message</source>
        <translation>Nachricht kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR-Code</translation>
    </message>
    <message>
        <source>Copy &amp;URI</source>
        <translation>&amp;URI kopieren</translation>
    </message>
    <message>
        <source>Copy &amp;Address</source>
        <translation>&amp;Addresse kopieren</translation>
    </message>
    <message>
        <source>&amp;Save Image...</source>
        <translation>Grafik &amp;speichern...</translation>
    </message>
    <message>
        <source>Request payment to %1</source>
        <translation>Zahlung anfordern an %1</translation>
    </message>
    <message>
        <source>Payment information</source>
        <translation>Zahlungsinformationen</translation>
    </message>
    <message>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <source>Resulting URI too long, try to reduce the text for label / message.</source>
        <translation>Resultierende URI ist zu lang, bitte den Text für Bezeichnung/Nachricht kürzen.</translation>
    </message>
    <message>
        <source>Error encoding URI into QR Code.</source>
        <translation>Beim Enkodieren der URI in den QR-Code ist ein Fehler aufgetreten.</translation>
    </message>
</context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
    <message>
        <source>(no message)</source>
        <translation>(keine Nachricht)</translation>
    </message>
    <message>
        <source>(no amount)</source>
        <translation>(kein Betrag)</translation>
    </message>
</context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>PCR überweisen</translation>
    </message>
    <message>
        <source>Coin Control Features</source>
        <translation>"Coin Control"-Funktionen</translation>
    </message>
    <message>
        <source>Inputs...</source>
        <translation>Inputs...</translation>
    </message>
    <message>
        <source>automatically selected</source>
        <translation>automatisch ausgewählt</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Unzureichender Kontostand!</translation>
    </message>
    <message>
        <source>Quantity:</source>
        <translation>Anzahl:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Byte:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Betrag:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Priorität:</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>mittel</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Gebühr:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>"Dust"</translation>
    </message>
    <message>
        <source>no</source>
        <translation>nein</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>Abzüglich Gebühr:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Wechselgeld:</translation>
    </message>
    <message>
        <source>If this is activated, but the change address is empty or invalid, change will be sent to a newly generated address.</source>
        <translation>Wenn dies aktivert, und die Wechselgeld-Adresse leer oder ungültig ist, wird das Wechselgeld einer neu erzeugten Adresse gutgeschrieben.</translation>
    </message>
    <message>
        <source>Custom change address</source>
        <translation>Benutzerdefinierte Wechselgeld-Adresse</translation>
    </message>
    <message>
        <source>Transaction Fee:</source>
        <translation>Transaktionsgebühr:</translation>
    </message>
    <message>
        <source>Choose...</source>
        <translation>Auswählen...</translation>
    </message>
    <message>
        <source>collapse fee-settings</source>
        <translation>Gebühreneinstellungen reduzieren</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Minimieren</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 duffs and the transaction is only 250 bytes, then "per kilobyte" only pays 250 duffs in fee,&lt;br /&gt;while "at least" pays 1000 duffs. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation>Wenn die benutzerdefinierten Gebühren auf 1000 duffs gesetzt sind und eine Transaktion hat nur 250 Bytes, dann kostet "pro Kilobyte" nur 250 duffs Gebühren,&lt;br/&gt; während "mindestens" 1000 duffs kostet. Transaktionen größer als 1 Kilobyte werden immer pro Kilobyte bezahlt.</translation>
    </message>
    <message>
        <source>If the custom fee is set to 1000 duffs and the transaction is only 250 bytes, then "per kilobyte" only pays 250 duffs in fee,&lt;br /&gt;while "total at least" pays 1000 duffs. For transactions bigger than a kilobyte both pay by kilobyte.</source>
        <translation>Wenn die benutzerdefinierten Gebühren auf 1000 duffs gesetzt sind und eine Transaktion hat nur 250 Bytes, dann kostet "pro Kilobyte" nur 250 duffs Gebühren, während "mindestens" 1000 duffs kostet. Transaktionen größer als 1 Kilobyte werden immer pro Kilobyte bezahlt.</translation>
    </message>
    <message>
        <source>Paying only the minimum fee is just fine as long as there is less transaction volume than space in the blocks.&lt;br /&gt;But be aware that this can end up in a never confirming transaction once there is more demand for capracoin transactions than the network can process.</source>
        <translation>Nur die minimalen Gebühren zu zahlen ist völlig ausreichend so lange in einem neuen Block der Blockkette noch genug Platz für neue Transaktionen ist.&lt;br /&gt; Bitte beachten Sie dass wenn dies in der Zukunft nicht mehr der Fall sein sollte Ihre Transaktion eventuell niemals in einen neuen Block aufgenommen werden wird, also niemals bestätigt wird.</translation>
    </message>
    <message>
        <source>per kilobyte</source>
        <translation>pro Kilobyte</translation>
    </message>
    <message>
        <source>total at least</source>
        <translation>mindestens</translation>
    </message>
    <message>
        <source>(read the tooltip)</source>
        <translation>(Kurzinfo lesen)</translation>
    </message>
    <message>
        <source>Recommended:</source>
        <translation>Empfohlen:</translation>
    </message>
    <message>
        <source>Custom:</source>
        <translation>Benutzerdefiniert:</translation>
    </message>
    <message>
        <source>(Smart fee not initialized yet. This usually takes a few blocks...)</source>
        <translation>("Intelligente" Gebühren sind noch nicht initialisiert. Dies dauert normalerweise ein paar Blöcke...)</translation>
    </message>
    <message>
        <source>Confirmation time:</source>
        <translation>Bestätigungszeit:</translation>
    </message>
    <message>
        <source>normal</source>
        <translation>normal</translation>
    </message>
    <message>
        <source>fast</source>
        <translation>schnell</translation>
    </message>
    <message>
        <source>Send as zero-fee transaction if possible</source>
        <translation>Wenn möglich als gebührenfreie Transaktion versenden</translation>
    </message>
    <message>
        <source>(confirmation may take longer)</source>
        <translation>(Bestätigung könnte länger dauern)</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Überweisung bestätigen</translation>
    </message>
    <message>
        <source>S&amp;end</source>
        <translation>&amp;Überweisen</translation>
    </message>
    <message>
        <source>Clear all fields of the form.</source>
        <translation>Alle Formularfelder zurücksetzen.</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Zurücksetzen</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>An mehrere Empfänger auf einmal überweisen</translation>
    </message>
    <message>
        <source>Add &amp;Recipient</source>
        <translation>Empfänger &amp;hinzufügen</translation>
    </message>
    <message>
        <source>Obfuscate</source>
        <translation>Obfuscate</translation>
    </message>
    <message>
        <source>InstantX</source>
        <translation>InstantX</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Kontostand:</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Anzahl kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy after fee</source>
        <translation>Abzüglich Gebühr kopieren</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Byte kopieren</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Priorität kopieren</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>"Dust" Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Wechselgeld kopieren</translation>
    </message>
    <message>
        <source>using</source>
        <translation>mittels</translation>
    </message>
    <message>
        <source>anonymous funds</source>
        <translation>anonymisierte Coins</translation>
    </message>
    <message>
        <source>(obfuscate requires this amount to be rounded up to the nearest %1).</source>
        <translation>(Obfuscate verlangt, dass dieser Betrag auf den nächsten %1 aufgerundet wird)</translation>
    </message>
    <message>
        <source>any available funds (not recommended)</source>
        <translation>beliebiger verfügbarer Coins (nicht empfohlen)</translation>
    </message>
    <message>
        <source>and InstantX</source>
        <translation>und InstantX</translation>
    </message>
    <message>
        <source>%1 to %2</source>
        <translation>%1 an %2</translation>
    </message>
    <message>
        <source>Are you sure you want to send?</source>
        <translation>Wollen Sie die Überweisung ausführen?</translation>
    </message>
    <message>
        <source>are added as transaction fee</source>
        <translation>werden als Transaktionsgebühr hinzugefügt</translation>
    </message>
    <message>
        <source>Total Amount = &lt;b&gt;%1&lt;/b&gt;&lt;br /&gt;= %2</source>
        <translation>Gesamtbetrag = &lt;b&gt;%1&lt;/b&gt;&lt;br /&gt;= %2</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Überweisung bestätigen</translation>
    </message>
    <message>
        <source>A fee %1 times higher than %2 per kB is considered an insanely high fee.</source>
        <translation>Gebühren %1 x höher als %2 pro Kilobyte sind wahnsinnig überhöht.</translation>
    </message>
    <message numerus="yes">
        <source>Estimated to begin confirmation within %n block(s).</source>
        <translation><numerusform>Geschätzter Beginn der Bestätigung in %n Block.</numerusform><numerusform>Geschätzter Beginn der Bestätigung in %n Blocks.</numerusform></translation>
    </message>
    <message>
        <source>The recipient address is not valid, please recheck.</source>
        <translation>Die Zahlungsadresse ist ungültig, bitte nochmals überprüfen.</translation>
    </message>
    <message>
        <source>&lt;b&gt;(%1 of %2 entries displayed)&lt;/b&gt;</source>
        <translation>&lt;b&gt;(%1 von %2 Einträgen angezeigt)&lt;/b&gt;</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Der zu zahlende Betrag muss größer als 0 sein.</translation>
    </message>
    <message>
        <source>The amount exceeds your balance.</source>
        <translation>Der angegebene Betrag übersteigt ihren Kontostand.</translation>
    </message>
    <message>
        <source>The total exceeds your balance when the %1 transaction fee is included.</source>
        <translation>Der angegebene Betrag übersteigt aufgrund der Transaktionsgebühr in Höhe von %1 ihren Kontostand.</translation>
    </message>
    <message>
        <source>Duplicate address found, can only send to each address once per send operation.</source>
        <translation>Doppelte Zahlungsadresse gefunden, pro Überweisung kann an jede Adresse nur einmalig etwas überwiesen werden.</translation>
    </message>
    <message>
        <source>Transaction creation failed!</source>
        <translation>Transaktionserstellung fehlgeschlagen!</translation>
    </message>
    <message>
        <source>The transaction was rejected! This might happen if some of the coins in your wallet were already spent, such as if you used a copy of wallet.dat and coins were spent in the copy but not marked as spent here.</source>
        <translation>Die Transaktion wurde abgelehnt! 
Dies kann passieren, wenn einige PCR aus ihrer Wallet bereits ausgegeben wurden. Beispielsweise weil Sie eine Kopie ihrer wallet.dat nutzten und die PCR dort ausgegeben haben. Diese Ausgaben sind in diesem Fall in der derzeit aktiven Wallet nicht vermerkt.</translation>
    </message>
    <message>
        <source>Error: The wallet was unlocked only to anonymize coins.</source>
        <translation>Fehler: das Wallet wurde nur zum Anonymisieren entsperrt.</translation>
    </message>
    <message>
        <source>Pay only the minimum fee of %1</source>
        <translation>Nur die minimalen Gebühren von %1 zahlen</translation>
    </message>
    <message>
        <source>Warning: Invalid PCR address</source>
        <translation>Warnung: ungültige PCR-Adresse</translation>
    </message>
    <message>
        <source>Warning: Unknown change address</source>
        <translation>Warnung: Unbekannte Wechselgeld-Adresse</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(keine Bezeichnung)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>This is a normal payment.</source>
        <translation>Dies ist eine normale Überweisung.</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>E&amp;mpfänger:</translation>
    </message>
    <message>
        <source>The PCR address to send the payment to</source>
        <translation>PCR-Adresse, an die überwiesen werden soll</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Bereits verwendete Adresse auswählen</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Adresse aus der Zwischenablage einfügen</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Remove this entry</source>
        <translation>Diesen Eintrag entfernen</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Bezeichnung:</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to the list of used addresses</source>
        <translation>Adressbezeichnung eingeben, die dann zusammen mit der Adresse der Liste bereits verwendeter Adressen hinzugefügt wird.</translation>
    </message>
    <message>
        <source>A&amp;mount:</source>
        <translation>Betra&amp;g:</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Nachricht:</translation>
    </message>
    <message>
        <source>A message that was attached to the capracoin: URI which will be stored with the transaction for your reference. Note: This message will not be sent over the PCR network.</source>
        <translation>Eine an die "capracoin:"-URI angefügte Nachricht, die zusammen mit der Transaktion gespeichert wird. Hinweis: Diese Nachricht wird nicht über das PCR-Netzwerk gesendet.</translation>
    </message>
    <message>
        <source>This is an unverified payment request.</source>
        <translation>Dies is eine unverifizierte Zahlungsanforderung.</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Empfänger:</translation>
    </message>
    <message>
        <source>Memo:</source>
        <translation>Memo:</translation>
    </message>
    <message>
        <source>This is a verified payment request.</source>
        <translation>Dies is eine verifizierte Zahlungsanforderung.</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Adressbezeichnung eingeben (diese wird zusammen mit der Adresse dem Adressbuch hinzugefügt)</translation>
    </message>
</context>
<context>
    <name>ShutdownWindow</name>
    <message>
        <source>Paycore Core is shutting down...</source>
        <translation>PCR-Core wird herunter gefahren...</translation>
    </message>
    <message>
        <source>Do not shut down the computer until this window disappears.</source>
        <translation>Fahren Sie den Computer nicht herunter, bevor dieses Fenster verschwindet.</translation>
    </message>
</context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>Signatures - Sign / Verify a Message</source>
        <translation>Signaturen - eine Nachricht signieren / verifizieren</translation>
    </message>
    <message>
        <source>&amp;Sign Message</source>
        <translation>Nachricht &amp;signieren</translation>
    </message>
    <message>
        <source>You can sign messages with your addresses to prove you own them. Be careful not to sign anything vague, as phishing attacks may try to trick you into signing your identity over to them. Only sign fully-detailed statements you agree to.</source>
        <translation>Sie können Nachrichten mit ihren Adressen signieren, um den Besitz dieser Adressen zu beweisen. Bitte nutzen Sie diese Funktion mit Vorsicht und nehmen Sie sich vor Phishingangriffen in Acht. Signieren Sie nur Nachrichten, mit denen Sie vollständig einverstanden sind.</translation>
    </message>
    <message>
        <source>The PCR address to sign the message with</source>
        <translation>PCR-Adresse, mit der die Nachricht signiert werden soll</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Bereits verwendete Adresse auswählen</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Adresse aus der Zwischenablage einfügen</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Zu signierende Nachricht hier eingeben</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Signatur</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Aktuelle Signatur in die Zwischenablage kopieren</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this PCR address</source>
        <translation>Die Nachricht signieren, um den Besitz dieser PCR-Adresse zu belegen</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>&amp;Nachricht signieren</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Alle "Nachricht signieren"-Felder zurücksetzen</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>&amp;Zurücksetzen</translation>
    </message>
    <message>
        <source>&amp;Verify Message</source>
        <translation>Nachricht &amp;verifizieren</translation>
    </message>
    <message>
        <source>Enter the signing address, message (ensure you copy line breaks, spaces, tabs, etc. exactly) and signature below to verify the message. Be careful not to read more into the signature than what is in the signed message itself, to avoid being tricked by a man-in-the-middle attack.</source>
        <translation>Geben Sie die signierende Adresse, Nachricht (achten Sie darauf Zeilenumbrüche, Leerzeichen, Tabulatoren usw. exakt zu kopieren) und Signatur unten ein, um die Nachricht zu verifizieren. Vorsicht, interpretieren Sie nicht mehr in die Signatur hinein, als in der signierten Nachricht selber enthalten ist, um nicht von einem Man-in-the-middle-Angriff hinters Licht geführt zu werden.</translation>
    </message>
    <message>
        <source>The PCR address the message was signed with</source>
        <translation>PCR-Adresse, mit der die Nachricht signiert worden ist</translation>
    </message>
    <message>
        <source>Verify the message to ensure it was signed with the specified PCR address</source>
        <translation>Die Nachricht verifizieren, um sicherzustellen, dass diese mit der angegebenen PCR-Adresse signiert wurde</translation>
    </message>
    <message>
        <source>Verify &amp;Message</source>
        <translation>&amp;Nachricht verifizieren</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Alle "Nachricht verifizieren"-Felder zurücksetzen</translation>
    </message>
    <message>
        <source>Click "Sign Message" to generate signature</source>
        <translation>Auf "Nachricht signieren" klicken, um die Signatur zu erzeugen</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Die eingegebene Adresse ist ungültig.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Bitte überprüfen Sie die Adresse und versuchen Sie es erneut.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Die eingegebene Adresse verweist nicht auf einen Schlüssel.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Wallet-Entsperrung wurde abgebrochen.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Privater Schlüssel zur eingegebenen Adresse ist nicht verfügbar.</translation>
    </message>
    <message>
        <source>Message signing failed.</source>
        <translation>Signierung der Nachricht fehlgeschlagen.</translation>
    </message>
    <message>
        <source>Message signed.</source>
        <translation>Nachricht signiert.</translation>
    </message>
    <message>
        <source>The signature could not be decoded.</source>
        <translation>Die Signatur konnte nicht dekodiert werden.</translation>
    </message>
    <message>
        <source>Please check the signature and try again.</source>
        <translation>Bitte überprüfen Sie die Signatur und versuchen Sie es erneut.</translation>
    </message>
    <message>
        <source>The signature did not match the message digest.</source>
        <translation>Die Signatur entspricht nicht dem "Message Digest".</translation>
    </message>
    <message>
        <source>Message verification failed.</source>
        <translation>Verifikation der Nachricht fehlgeschlagen.</translation>
    </message>
    <message>
        <source>Message verified.</source>
        <translation>Nachricht verifiziert.</translation>
    </message>
</context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>Paycore Core</source>
        <translation>Paycore Core</translation>
    </message>
    <message>
        <source>Version %1</source>
        <translation>Version %1</translation>
    </message>
    <message>
        <source>The Bitcoin Core developers</source>
        <translation>Die "Bitcoin Core"-Entwickler</translation>
    </message>
    <message>
        <source>The Paycore Core developers</source>
        <translation>Die "Paycore Core"-Entwickler</translation>
    </message>
    <message>
        <source>[testnet]</source>
        <translation>[Testnetz]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    <message>
        <source>KB/s</source>
        <translation>KB/s</translation>
    </message>
</context>
<context>
    <name>TransactionDesc</name>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Geöffnet für %n weiteren Block</numerusform><numerusform>Geöffnet für %n weitere Blöcke</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Offen bis %1</translation>
    </message>
    <message>
        <source>conflicted</source>
        <translation>in Konflikt stehend</translation>
    </message>
    <message>
        <source>%1/offline (verified via Instantx)</source>
        <translation>%1/offline (Überprüft durch InstantX)</translation>
    </message>
    <message>
        <source>%1/confirmed (verified via Instantx)</source>
        <translation>%1/bestätigt (Überprüft durch InstantX)</translation>
    </message>
    <message>
        <source>%1 confirmations (verified via Instantx)</source>
        <translation>%1 Bestätigungen (Überprüft durch InstantX)</translation>
    </message>
    <message>
        <source>%1/offline</source>
        <translation>%1/offline</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/unbestätigt</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 Bestätigungen</translation>
    </message>
    <message>
        <source>%1/offline (InstantX verification in progress - %2 of %3 signatures)</source>
        <translation>%1/offline (Überprüfung durch InstantX - %2 von %3 Signaturen)</translation>
    </message>
    <message>
        <source>%1/confirmed (InstantX verification in progress - %2 of %3 signatures )</source>
        <translation>%1/bestätigt (Überprüfung durch InstantX - %2 von %3 Signaturen)</translation>
    </message>
    <message>
        <source>%1 confirmations (InstantX verification in progress - %2 of %3 signatures)</source>
        <translation>%1 Bestätigungen (Überprüfung durch InstantX - %2 von %3 Signaturen)</translation>
    </message>
    <message>
        <source>%1/offline (InstantX verification failed)</source>
        <translation>%1/offline (Überprüfung durch InstantX fehlgeschlagen)</translation>
    </message>
    <message>
        <source>%1/confirmed (InstantX verification failed)</source>
        <translation>%1/bestätigt (Überprüfung durch InstantX fehlgeschlagen)</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, wurde noch nicht erfolgreich übertragen</translation>
    </message>
    <message numerus="yes">
        <source>, broadcast through %n node(s)</source>
        <translation><numerusform>, über %n Knoten übertragen</numerusform><numerusform>, über %n Knoten übertragen</numerusform></translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Quelle</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Erzeugt</translation>
    </message>
    <message>
        <source>From</source>
        <translation>Von</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>unbekannt</translation>
    </message>
    <message>
        <source>To</source>
        <translation>An</translation>
    </message>
    <message>
        <source>own address</source>
        <translation>eigene Adresse</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>beobachtet</translation>
    </message>
    <message>
        <source>label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Gutschrift</translation>
    </message>
    <message numerus="yes">
        <source>matures in %n more block(s)</source>
        <translation><numerusform>reift noch %n Block</numerusform><numerusform>reift noch %n weitere Blöcke</numerusform></translation>
    </message>
    <message>
        <source>not accepted</source>
        <translation>nicht angenommen</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Belastung</translation>
    </message>
    <message>
        <source>Total debit</source>
        <translation>Gesamtbelastung</translation>
    </message>
    <message>
        <source>Total credit</source>
        <translation>Gesamtgutschrift</translation>
    </message>
    <message>
        <source>Transaction fee</source>
        <translation>Transaktionsgebühr</translation>
    </message>
    <message>
        <source>Net amount</source>
        <translation>Nettobetrag</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Nachricht</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <source>Transaction ID</source>
        <translation>Transaktions-ID</translation>
    </message>
    <message>
        <source>Merchant</source>
        <translation>Händler</translation>
    </message>
    <message>
        <source>Generated coins must mature %1 blocks before they can be spent. When you generated this block, it was broadcast to the network to be added to the block chain. If it fails to get into the chain, its state will change to "not accepted" and it won't be spendable. This may occasionally happen if another node generates a block within a few seconds of yours.</source>
        <translation>Erzeugte PCR müssen %1 Blöcke lang reifen, bevor sie ausgegeben werden können. Als Sie diesen Block erzeugten, wurde er an das Netzwerk übertragen, um ihn der Blockkette hinzuzufügen. Falls dies fehlschlägt wird der Status in "nicht angenommen" geändert und Sie werden keine PCR gutgeschrieben bekommen. Das kann gelegentlich passieren, wenn ein anderer Knoten einen Block fast zeitgleich erzeugt.</translation>
    </message>
    <message>
        <source>Debug information</source>
        <translation>Debuginformationen</translation>
    </message>
    <message>
        <source>Transaction</source>
        <translation>Transaktion</translation>
    </message>
    <message>
        <source>Inputs</source>
        <translation>Eingaben</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Betrag</translation>
    </message>
    <message>
        <source>true</source>
        <translation>wahr</translation>
    </message>
    <message>
        <source>false</source>
        <translation>falsch</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Transaktionsdetails</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Dieser Bereich zeigt eine detaillierte Beschreibung der Transaktion an</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message numerus="yes">
        <source>Open for %n more block(s)</source>
        <translation><numerusform>Geöffnet für %n weiteren Block</numerusform><numerusform>Geöffnet für %n weitere Blöcke</numerusform></translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Offen bis %1</translation>
    </message>
    <message>
        <source>Offline</source>
        <translation>Offline</translation>
    </message>
    <message>
        <source>Unconfirmed</source>
        <translation>Unbestätigt</translation>
    </message>
    <message>
        <source>Confirming (%1 of %2 recommended confirmations)</source>
        <translation>Wird bestätigt (%1 von %2 empfohlenen Bestätigungen)</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Bestätigt (%1 Bestätigungen)</translation>
    </message>
    <message>
        <source>Conflicted</source>
        <translation>in Konflikt stehend</translation>
    </message>
    <message>
        <source>Immature (%1 confirmations, will be available after %2)</source>
        <translation>Unreif (%1 Bestätigungen, wird verfügbar sein nach %2)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Dieser Block wurde von keinem anderen Knoten empfangen und wird wahrscheinlich nicht angenommen werden!</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Erzeugt, jedoch nicht angenommen</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Empfangen über</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Empfangen von</translation>
    </message>
    <message>
        <source>Received via Obfuscate</source>
        <translation>über/durch Obfuscate empfangen</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Überwiesen an</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Eigenüberweisung</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Erarbeitet</translation>
    </message>
    <message>
        <source>Obfuscate Denominate</source>
        <translation>Obfuscate Stückelung</translation>
    </message>
    <message>
        <source>Obfuscate Collateral Payment</source>
        <translation>Obfuscate Sicherheits-Zahlung</translation>
    </message>
    <message>
        <source>Obfuscate Make Collateral Inputs</source>
        <translation>Obfuscate Sicherheits-Eingänge machen</translation>
    </message>
    <message>
        <source>Obfuscate Create Denominations</source>
        <translation>Obfuscate Stückelungs-Gebühr</translation>
    </message>
    <message>
        <source>Obfuscated</source>
        <translation>Obfuscate</translation>
    </message>
    <message>
        <source>watch-only</source>
        <translation>beobachtet</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(k.A.)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>Transaktionsstatus, fahren Sie mit der Maus über dieses Feld, um die Anzahl der Bestätigungen zu sehen.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Datum und Uhrzeit zu der die Transaktion empfangen wurde.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Art der Transaktion</translation>
    </message>
    <message>
        <source>Whether or not a watch-only address is involved in this transaction.</source>
        <translation>Zeigt ob eine beobachtete Adresse in dieser Transaktion beteiligt ist.</translation>
    </message>
    <message>
        <source>Destination address of transaction.</source>
        <translation>Zieladresse der Transaktion</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Der Betrag, der dem Kontostand abgezogen oder hinzugefügt wurde.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Heute</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Diese Woche</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Diesen Monat</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Letzten Monat</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Dieses Jahr</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Zeitraum...</translation>
    </message>
    <message>
        <source>Most Common</source>
        <translation>Gängigste</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Empfangen über</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Überwiesen an</translation>
    </message>
    <message>
        <source>Obfuscated</source>
        <translation>Obfuscate</translation>
    </message>
    <message>
        <source>Obfuscate Make Collateral Inputs</source>
        <translation>Obfuscate Sicherheits-Eingänge machen</translation>
    </message>
    <message>
        <source>Obfuscate Create Denominations</source>
        <translation>Obfuscate Stückelungs-Gebühr</translation>
    </message>
    <message>
        <source>Obfuscate Denominate</source>
        <translation>Obfuscate Stückelung</translation>
    </message>
    <message>
        <source>Obfuscate Collateral Payment</source>
        <translation>Obfuscate Sicherheits-Zahlung</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>Eigenüberweisung</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Erarbeitet</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Andere</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Zu suchende Adresse oder Bezeichnung eingeben</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Minimaler Betrag</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Adresse kopieren</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Bezeichnung kopieren</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Betrag kopieren</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Transaktions-ID kopieren</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Bezeichnung bearbeiten</translation>
    </message>
    <message>
        <source>Show transaction details</source>
        <translation>Transaktionsdetails anzeigen</translation>
    </message>
    <message>
        <source>Export Transaction History</source>
        <translation>Transaktionsverlauf exportieren</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Kommagetrennte-Datei (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Bestätigt</translation>
    </message>
    <message>
        <source>Watch-only</source>
        <translation>Beobachtet</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Bezeichnung</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Exportieren fehlgeschlagen</translation>
    </message>
    <message>
        <source>There was an error trying to save the transaction history to %1.</source>
        <translation>Beim Speichern des Transaktionsverlaufs nach %1 ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>Exporting Successful</source>
        <translation>Exportieren erfolgreich</translation>
    </message>
    <message>
        <source>The transaction history was successfully saved to %1.</source>
        <translation>Speichern des Transaktionsverlaufs nach %1 war erfolgreich.</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Zeitraum:</translation>
    </message>
    <message>
        <source>to</source>
        <translation>bis</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    <message>
        <source>Unit to show amounts in. Click to select another unit.</source>
        <translation>Angezeigte Einheit. Anklicken, um andere Einheit zu wählen.</translation>
    </message>
</context>
<context>
    <name>WalletFrame</name>
    <message>
        <source>No wallet has been loaded.</source>
        <translation>Es wurde keine Wallet geladen.</translation>
    </message>
</context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>PCR überweisen</translation>
    </message>
    <message>
        <source>InstantX doesn't support sending values that high yet. Transactions are currently limited to %1 DNET.</source>
        <translation>InstantX unterstützt das Versenden von Beträgen dieser Höhe noch nicht. Transaktionen sind zur Zeit auf maximal %1 DNET begrenzt.</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>E&amp;xportieren</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Daten der aktuellen Ansicht in eine Datei exportieren</translation>
    </message>
    <message>
        <source>Selected amount:</source>
        <translation>Ausgewählter Betrag:</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Wallet sichern</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Wallet-Daten (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>Sicherung fehlgeschlagen</translation>
    </message>
    <message>
        <source>There was an error trying to save the wallet data to %1.</source>
        <translation>Beim Speichern der Wallet-Daten nach %1 ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <source>Backup Successful</source>
        <translation>Sicherung erfolgreich</translation>
    </message>
    <message>
        <source>The wallet data was successfully saved to %1.</source>
        <translation>Speichern der Wallet-Daten nach %1 war erfolgreich.</translation>
    </message>
</context>
<context>
    <name>capracoin-core</name>
    <message>
        <source>Bind to given address and always listen on it. Use [host]:port notation for IPv6</source>
        <translation>An die angegebene Adresse binden und immer abhören. Für IPv6 "[Host]:Port"-Schreibweise verwenden</translation>
    </message>
    <message>
        <source>Cannot obtain a lock on data directory %s. Paycore Core is probably already running.</source>
        <translation>Das Programm kann das Daten-Verzeichnis %s nicht als "in Verwendung" markieren. Wahrscheinlich läuft das Programm bereits.</translation>
    </message>
    <message>
        <source>Obfuscate uses exact denominated amounts to send funds, you might simply need to anonymize some more coins.</source>
        <translation>Obfuscate benutzt exakt gestückelte Beträge zum Versenden, Sie müssen dafür möglicherweise noch mehr PCR anonymisieren.</translation>
    </message>
    <message>
        <source>Enter regression test mode, which uses a special chain in which blocks can be solved instantly.</source>
        <translation>Regressionstest-Modus aktivieren, der eine spezielle Blockkette nutzt, in der Blöcke sofort gelöst werden können.</translation>
    </message>
    <message>
        <source>Error: Listening for incoming connections failed (listen returned error %s)</source>
        <translation>Fehler: Abhören nach eingehenden Verbindungen fehlgeschlagen (Fehler %s)</translation>
    </message>
    <message>
        <source>Execute command when a relevant alert is received or we see a really long fork (%s in cmd is replaced by message)</source>
        <translation>Befehl ausführen wenn ein relevanter Alarm empfangen wird oder wir einen wirklich langen Fork entdecken (%s im Befehl wird durch die Nachricht ersetzt)</translation>
    </message>
    <message>
        <source>Execute command when a wallet transaction changes (%s in cmd is replaced by TxID)</source>
        <translation>Befehl ausführen wenn sich eine Wallet-Transaktion verändert (%s im Befehl wird durch die TxID ersetzt)</translation>
    </message>
    <message>
        <source>Execute command when the best block changes (%s in cmd is replaced by block hash)</source>
        <translation>Befehl ausführen wenn der beste Block wechselt (%s im Befehl wird durch den Hash des Blocks ersetzt)</translation>
    </message>
    <message>
        <source>In this mode -genproclimit controls how many blocks are generated immediately.</source>
        <translation>In diesem Modus legt -genproclimit fest, wie viele Blöcke sofort erzeugt werden.</translation>
    </message>
    <message>
        <source>InstantX requires inputs with at least 6 confirmations, you might need to wait a few minutes and try again.</source>
        <translation>InstantX benötigt Zahlungseingänge mit mindestens 6 Bestätigungen, warten Sie also ein paar Minuten und versuchen Sie es dann erneut.</translation>
    </message>
    <message>
        <source>Name to construct url for KeePass entry that stores the wallet passphrase</source>
        <translation>Name, um eine URL für den KeyPass-Eintrag zu erzeugen, der die Wallet-Passphrase speichert.</translation>
    </message>
    <message>
        <source>Query for peer addresses via DNS lookup, if low on addresses (default: 1 unless -connect)</source>
        <translation>Abfrage der Peer-Adressen über DNS, falls es wenige Adressen gibt (Standard: 1, außer wenn -connect konfiguriert wurde)</translation>
    </message>
    <message>
        <source>Set maximum size of high-priority/low-fee transactions in bytes (default: %d)</source>
        <translation>Maximale Größe in Byte von Transaktionen hoher Priorität/mit niedrigen Gebühren festlegen (Standard: %d)</translation>
    </message>
    <message>
        <source>Set the number of script verification threads (%u to %d, 0 = auto, &lt;0 = leave that many cores free, default: %d)</source>
        <translation>Maximale Anzahl an Skript-Verifizierungs-Threads festlegen (%u bis %d, 0 = automatisch, &lt;0 = so viele Kerne frei lassen, Standard: %d)</translation>
    </message>
    <message>
        <source>This is a pre-release test build - use at your own risk - do not use for mining or merchant applications</source>
        <translation>Dies ist eine Vorab-Testversion - Verwendung auf eigene Gefahr - nicht für Mining- oder Handelsanwendungen nutzen!</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer. Paycore Core is probably already running.</source>
        <translation>Paycore Core den Prozess %s auf dem Computer nicht an sich binden. Wahrscheinlich läuft das Programm bereits.</translation>
    </message>
    <message>
        <source>Unable to locate enough Obfuscate denominated funds for this transaction.</source>
        <translation>Für diese Transaktion konnten nicht genug mit Obfuscate gestückelte Beträge gefunden werden.</translation>
    </message>
    <message>
        <source>Unable to locate enough Obfuscate non-denominated funds for this transaction that are not equal 1000 DNET.</source>
        <translation>Für diese Transaktion konnten nicht genug nicht mit Obfuscate gestückelte Beträge gefunden werden, die ungleich 1000 DNET sind.</translation>
    </message>
    <message>
        <source>Warning: -paytxfee is set very high! This is the transaction fee you will pay if you send a transaction.</source>
        <translation>Warnung: -paytxfee ist auf einen sehr hohen Wert festgelegt! Dies ist die Gebühr die beim Senden einer Transaktion fällig wird.</translation>
    </message>
    <message>
        <source>Warning: The network does not appear to fully agree! Some miners appear to be experiencing issues.</source>
        <translation>Warnung: Das Netzwerk scheint nicht vollständig übereinzustimmen! Einige Miner scheinen Probleme zu haben.</translation>
    </message>
    <message>
        <source>Warning: We do not appear to fully agree with our peers! You may need to upgrade, or other nodes may need to upgrade.</source>
        <translation>Warnung: Wir scheinen nicht vollständig mit unseren Gegenstellen übereinzustimmen! Sie oder die anderen Knoten müssen unter Umständen ihre Client-Software aktualisieren.</translation>
    </message>
    <message>
        <source>Warning: error reading wallet.dat! All keys read correctly, but transaction data or address book entries might be missing or incorrect.</source>
        <translation>Warnung: Lesen von wallet.dat fehlgeschlagen! Alle Schlüssel wurden korrekt gelesen, Transaktionsdaten bzw. Adressbucheinträge fehlen aber möglicherweise oder sind inkorrekt.</translation>
    </message>
    <message>
        <source>Warning: wallet.dat corrupt, data salvaged! Original wallet.dat saved as wallet.{timestamp}.bak in %s; if your balance or transactions are incorrect you should restore from a backup.</source>
        <translation>Warnung: wallet.dat beschädigt, Datenrettung erfolgreich! Original wallet.dat wurde als wallet.{Zeitstempel}.dat in %s gespeichert. Falls ihr Kontostand oder Transaktionen nicht korrekt sind, sollten Sie dem vorangegangenen Zustand durch die Datensicherung wiederherstellen.</translation>
    </message>
    <message>
        <source>You must specify a masternodeprivkey in the configuration. Please see documentation for help.</source>
        <translation>Es muss ein Masternode-Geheimschlüssel (masternodeprivkey) in der Konfiguration angegeben werden. Für weitere Informationen siehe Dokumentation.</translation>
    </message>
    <message>
        <source>(default: 1)</source>
        <translation>(Standard: 1)</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Kommandozeilen- und JSON-RPC-Befehle annehmen</translation>
    </message>
    <message>
        <source>Accept connections from outside (default: 1 if no -proxy or -connect)</source>
        <translation>Eingehende Verbindungen annehmen (Standard: 1, wenn nicht -proxy oder -connect)</translation>
    </message>
    <message>
        <source>Add a node to connect to and attempt to keep the connection open</source>
        <translation>Mit dem angegebenen Knoten verbinden und versuchen die Verbindung aufrecht zu erhalten</translation>
    </message>
    <message>
        <source>Allow DNS lookups for -addnode, -seednode and -connect</source>
        <translation>Erlaube DNS-Abfragen für -addnode, -seednode und -connect</translation>
    </message>
    <message>
        <source>Already have that input.</source>
        <translation>Haben diesen Eintrag bereits.</translation>
    </message>
    <message>
        <source>Attempt to recover private keys from a corrupt wallet.dat</source>
        <translation>Versuchen, private Schlüssel aus einer beschädigten wallet.dat wiederherzustellen</translation>
    </message>
    <message>
        <source>Block creation options:</source>
        <translation>Blockerzeugungsoptionen:</translation>
    </message>
    <message>
        <source>Can't denominate: no compatible inputs left.</source>
        <translation>Kann nicht zerstückeln: keine kompatiblen Eingänge übrig.</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Wallet kann nicht auf eine ältere Version herabgestuft werden</translation>
    </message>
    <message>
        <source>Cannot resolve -bind address: '%s'</source>
        <translation>Kann Adresse in -bind nicht auflösen: '%s'</translation>
    </message>
    <message>
        <source>Cannot resolve -externalip address: '%s'</source>
        <translation>Kann Adresse in -externalip nicht auflösen: '%s'</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Standardadresse kann nicht geschrieben werden</translation>
    </message>
    <message>
        <source>Collateral not valid.</source>
        <translation>Sicherheitszahlung nicht gültig.</translation>
    </message>
    <message>
        <source>Connect only to the specified node(s)</source>
        <translation>Mit nur dem oder den angegebenen Knoten verbinden</translation>
    </message>
    <message>
        <source>Connect to a node to retrieve peer addresses, and disconnect</source>
        <translation>Mit dem angegebenen Knoten verbinden, um Adressen von Gegenstellen abzufragen, danach trennen</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Verbindungsoptionen:</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Beschädigte Blockdatenbank erkannt</translation>
    </message>
    <message>
        <source>Obfuscate options:</source>
        <translation>Obfuscate Optionen:</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>Debugging-/Testoptionen:</translation>
    </message>
    <message>
        <source>Discover own IP address (default: 1 when listening and no -externalip)</source>
        <translation>Eigene IP-Adresse erkennen (Standard: 1, wenn abgehört wird und nicht -externalip)</translation>
    </message>
    <message>
        <source>Do not load the wallet and disable wallet RPC calls</source>
        <translation>Die Wallet nicht laden und Wallet-RPC-Aufrufe deaktivieren</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Möchten Sie die Blockdatenbank jetzt neu aufbauen?</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Laden abgeschlossen</translation>
    </message>
    <message>
        <source>Entries are full.</source>
        <translation>Warteschlange ist voll.</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Fehler beim Initialisieren der Blockdatenbank</translation>
    </message>
    <message>
        <source>Error initializing wallet database environment %s!</source>
        <translation>Fehler beim Initialisieren der Wallet-Datenbankumgebung %s!</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Fehler beim Laden der Blockdatenbank</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Fehler beim Laden von wallet.dat</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Fehler beim Laden von wallet.dat: Wallet beschädigt</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Fehler beim Öffnen der Blockdatenbank</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>Fehler beim Lesen der Datenbank, Anwendung wird heruntergefahren.</translation>
    </message>
    <message>
        <source>Error recovering public key.</source>
        <translation>Fehler bei der Wiederherstellung des öffentlichen Schlüssels.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Fehler: Zu wenig freier Speicherplatz auf dem Datenträger!</translation>
    </message>
    <message>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation>Fehler: Wallet gesperrt, Transaktion kann nicht erstellt werden!</translation>
    </message>
    <message>
        <source>Error: You already have pending entries in the Obfuscate pool</source>
        <translation>Fehler: Es sind bereits anstehende Einträge im Obfuscate-Pool</translation>
    </message>
    <message>
        <source>Failed to listen on any port. Use -listen=0 if you want this.</source>
        <translation>Fehler, es konnte kein Port abgehört werden. Wenn dies so gewünscht wird -listen=0 verwenden.</translation>
    </message>
    <message>
        <source>Failed to read block</source>
        <translation>Lesen des Blocks fehlgeschlagen</translation>
    </message>
    <message>
        <source>If &lt;category&gt; is not supplied, output all debugging information.</source>
        <translation>Wenn &lt;category&gt; nicht angegeben wird, jegliche Debugginginformationen ausgeben.</translation>
    </message>
    <message>
        <source>(1 = keep tx meta data e.g. account owner and payment request information, 2 = drop tx meta data)</source>
        <translation>(1 = Transaktions-Metadaten wie z.B. Kontoinhaber behalten, 2 = Metadaten verwerfen)</translation>
    </message>
    <message>
        <source>Allow JSON-RPC connections from specified source. Valid for &lt;ip&gt; are a single IP (e.g. 1.2.3.4), a network/netmask (e.g. 1.2.3.4/255.255.255.0) or a network/CIDR (e.g. 1.2.3.4/24). This option can be specified multiple times</source>
        <translation>JSON-RPC Verbindungen von einer bestimmten Quelle zulassen. Für &lt;ip&gt; sind einzelne IPs (z.B. 1.2.3.4), Netzwerk/Netzmasken (z.B. 1.2.3.4/255.255.255.0) oder Netzwerk/CIDR (z.B. 1.2.3.4/24) erlaubt. Diese Option kann mehrmals eingetragen werden.</translation>
    </message>
    <message>
        <source>An error occurred while setting up the RPC address %s port %u for listening: %s</source>
        <translation>Beim Einrichten der RPC-Adresse %s, Port %u zum Abhören von %s ist ein Fehler aufgetreten</translation>
    </message>
    <message>
        <source>Bind to given address and whitelist peers connecting to it. Use [host]:port notation for IPv6</source>
        <translation>An die angegebene Adresse binden und Gegenstellen in die Liste der erlaubten Gegenstellen aufnehmen. Für IPv6 "[Host]:Port"-Schreibweise verwenden</translation>
    </message>
    <message>
        <source>Bind to given address to listen for JSON-RPC connections. Use [host]:port notation for IPv6. This option can be specified multiple times (default: bind to all interfaces)</source>
        <translation>Für JSON-RPC Verbindugen an die angegebene Adresse binden. Für IPv6 "[Host]:Port"-Schreibweise verwenden. Diese Option kann mehrmals eingetragen werden. (Standard: an alle verbinden)</translation>
    </message>
    <message>
        <source>Change automatic finalized budget voting behavior. mode=auto: Vote for only exact finalized budget match to my generated budget. (string, default: auto)</source>
        <translation>Wahlverhalten für Abschlussbudget ändern. mode=auto: nur wählen, wenn Abschlussbudget genau meinem generierten Budget entspricht. (Standard: auto)</translation>
    </message>
    <message>
        <source>Continuously rate-limit free transactions to &lt;n&gt;*1000 bytes per minute (default:%u)</source>
        <translation>Anzahl der freien Transaktionen auf &lt;n&gt; * 1000 Byte pro Minute begrenzen (Standard: %u)</translation>
    </message>
    <message>
        <source>Create new files with system default permissions, instead of umask 077 (only effective with disabled wallet functionality)</source>
        <translation>Neue Dateien mit den System-Standardberechtigungen (anstatt 077) erzeugen (nur bei deaktiviertem Wallet möglich)</translation>
    </message>
    <message>
        <source>Delete all wallet transactions and only recover those parts of the blockchain through -rescan on startup</source>
        <translation>Lösche alle Wallet-Transaktionen stelle nur diese mittels -rescan beim nächsten Start des Wallets wieder her.</translation>
    </message>
    <message>
        <source>Disable all PCR specific functionality (Masternodes, Obfuscate, InstantX, Budgeting) (0-1, default: %u)</source>
        <translation>Deaktiviere all PCR-spezifischen Funktionen (Masternodes, Obfuscate, InstantX, Budgeting) (0-1, Standard: %u)</translation>
    </message>
    <message>
        <source>Distributed under the MIT software license, see the accompanying file COPYING or &lt;http://www.opensource.org/licenses/mit-license.php&gt;.</source>
        <translation>Unter MIT Software Lizenz zur Verfügung gestellt, siehe beigefügte Datei COPYING oder &lt;http://www.opensource.org/licenses/mit-license.php&gt;.</translation>
    </message>
    <message>
        <source>Enable Instantx, show confirmations for locked transactions (bool, default: %s)</source>
        <translation>Aktiviere InstantX, zeige Bestätigungen für gesperrte Transaktionen an (bool, Standard: %s)</translation>
    </message>
    <message>
        <source>Enable use of automated obfuscate for funds stored in this wallet (0-1, default: %u)</source>
        <translation>Aktiviere Obfuscate automatisch (0-1, Standard: %u)</translation>
    </message>
    <message>
        <source>Error: Unsupported argument -socks found. Setting SOCKS version isn't possible anymore, only SOCKS5 proxies are supported.</source>
        <translation>Fehler: Parameter -socks wird nicht mehr unterstützt. Setzen der SOCKS-Version ist nicht mehr möglich, es werden nur noch SOCKS5 Proxies unterstützt.</translation>
    </message>
    <message>
        <source>Fees (in DNET/Kb) smaller than this are considered zero fee for relaying (default: %s)</source>
        <translation>Niedrigere Gebühren (in DNET pro Kb) als diese werden bei der Vermittlung als gebührenfrei angesehen (Standard: %s)</translation>
    </message>
    <message>
        <source>Fees (in DNET/Kb) smaller than this are considered zero fee for transaction creation (default: %s)</source>
        <translation>Niedrigere Gebühren (in DNET pro Kb) als diese werden bei der Transaktionserzeugung als gebührenfrei angesehen (Standard: %s)</translation>
    </message>
    <message>
        <source>Flush database activity from memory pool to disk log every &lt;n&gt; megabytes (default: %u)</source>
        <translation>Datenbankaktivitäten vom Arbeitsspeicher-Pool alle &lt;n&gt; Megabyte auf den Datenträger schreiben (Standard: %u)</translation>
    </message>
    <message>
        <source>Found unconfirmed denominated outputs, will wait till they confirm to continue.</source>
        <translation>Unbestätigte für Obfuscate vorbereitete Ausgabebeträge gefunden, warte bis sie bestätigt sind bevor weitergemacht wird.</translation>
    </message>
    <message>
        <source>How thorough the block verification of -checkblocks is (0-4, default: %u)</source>
        <translation>Legt fest, wie gründlich die Blockverifikation von -checkblocks ist (0-4, Standard: %u)</translation>
    </message>
    <message>
        <source>If paytxfee is not set, include enough fee so transactions begin confirmation on average within n blocks (default: %u)</source>
        <translation>Falls paytxfee  nicht gesetzt wurde automatisch genug Transaktionsgebühren hinzufügen, um die Transaktion durchschnittlich innerhalb n Blöcken zu bestätigen (Standard: %u)</translation>
    </message>
    <message>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: '%s' (must be at least the minrelay fee of %s to prevent stuck transactions)</source>
        <translation>Ungültiger Betrag für -maxtxfee=&lt;amount&gt;: '%s' (Betrag muss mindestens minrelay von %s Gebühren sein um "hängende" Transaktionen zu vermeiden)</translation>
    </message>
    <message>
        <source>Log transaction priority and fee per kB when mining blocks (default: %u)</source>
        <translation>Transaktionspriorität und Gebühr pro kB beim Erzeugen von Blöcken protokollieren (Standard: %u)</translation>
    </message>
    <message>
        <source>Maintain a full transaction index, used by the getrawtransaction rpc call (default: %u)</source>
        <translation>Einen vollständigen Transaktionsindex für den getrawtransaction RPC-Aufruf führen (Standard: %u)</translation>
    </message>
    <message>
        <source>Maximum size of data in data carrier transactions we relay and mine (default: %u)</source>
        <translation>Maximale Datengröße für von uns weitergegebenen Übermittlungstransaktionen (Standard: %u)</translation>
    </message>
    <message>
        <source>Maximum total fees to use in a single wallet transaction, setting too low may abort large transactions (default: %s)</source>
        <translation>Maximale Gesamtgebühren für eine einzelne Transaktion.  Sind diese Gebühren zu gering könnten große Transaktionen evtl. abgebrochen werden (Standard: %s)</translation>
    </message>
    <message>
        <source>Number of seconds to keep misbehaving peers from reconnecting (default: %u)</source>
        <translation>Anzahl Sekunden, während denen sich nicht konform verhaltenden Gegenstellen die Wiederverbindung verweigert wird (Standard: %u)</translation>
    </message>
    <message>
        <source>Output debugging information (default: %u, supplying &lt;category&gt; is optional)</source>
        <translation>Debugging-Informationen ausgeben (Standard: %u, &lt;category&gt; anzugeben ist optional)</translation>
    </message>
    <message>
        <source>Provide liquidity to Obfuscate by infrequently mixing coins on a continual basis (0-100, default: %u, 1=very frequent, high fees, 100=very infrequent, low fees)</source>
        <translation>Durch diese Einstellung können Sie dem Obfuscate-Netzwerk zusätzliche Liquidität zur Verfügung stellen in dem Sie von Zeit zu Zeit bereits anonymisierte PCR wieder dem Mixing-Prozess zuführen. (0-100, 0=aus, 1=sehr oft, 100=sehr selten (wenig Gebühren). Standard: %u)</translation>
    </message>
    <message>
        <source>Require high priority for relaying free or low-fee transactions (default:%u)</source>
        <translation>Verlange hohe Priorität für die Vermittlung von kostenlosen oder mit niedrigen Gebühren versehenen Transaktionen (Standard: %u)</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file (default: %u)</source>
        <translation>Rückverfolgungs- und Debuginformationen an die Konsole senden, anstatt sie in debug.log zu schreiben (Standard: %u)</translation>
    </message>
    <message>
        <source>Set the number of threads for coin generation if enabled (-1 = all cores, default: %d)</source>
        <translation>Legt ein Prozessor-/CPU-Kernlimit fest, wenn CPU-Mining aktiviert ist (-1 = unbegrenzt, Standard: %d)</translation>
    </message>
    <message>
        <source>Show N confirmations for a successfully locked transaction (0-9999, default: %u)</source>
        <translation>Anzahl Bestätigungen  für eine erfolgreich gesperrte Transaktion (0-9999, voreingestellt: %u)</translation>
    </message>
    <message>
        <source>This product includes software developed by the OpenSSL Project for use in the OpenSSL Toolkit &lt;https://www.openssl.org/&gt; and cryptographic software written by Eric Young and UPnP software written by Thomas Bernard.</source>
        <translation>Dieses Produkt enthält vom OpenSSL-Projekt entwickelte Software zur Benutzung des OpenSSL Toolkit &lt;https://www.openssl.org/&gt;, kryptographische Software geschrieben von Eric Young und UPnP Software geschrieben von Thomas Bernard.</translation>
    </message>
    <message>
        <source>To use capracoind, or the -server option to capracoin-qt, you must set an rpcpassword in the configuration file:
%s
It is recommended you use the following random password:
rpcuser=capracoinrpc
rpcpassword=%s
(you do not need to remember this password)
The username and password MUST NOT be the same.
If the file does not exist, create it with owner-readable-only file permissions.
It is also recommended to set alertnotify so you are notified of problems;
for example: alertnotify=echo %%s | mail -s "PCR Alert" admin@foo.com
</source>
        <translation>Um capracoind (oder capracoin-qt mit dem -server Parameter) zu benutzen müssen Sie ein rpcpasswort in dieser Konfigurationsdatei angeben:
%s
Es wird empfohlen das folgende Zufallspasswort zu verwenden:
rpcuser=capracoinrpc
rpcpassword=%s
(Sie müssen sich dieses Passwort nicht merken!)
Der Benutzername und das Passwort dürfen NICHT identisch sein.
Falls die Konfigurationsdatei nicht existiert, erzeugen Sie diese bitte mit Leserechten nur für den Dateibesitzer.
Es wird ebenfalls empfohlen alertnotify anzugeben, um im Problemfall benachrichtigt zu werden;
zum Beispiel: alertnotify=echo %%s | mail -s \"PCR Alert\" admin@foo.com</translation>
    </message>
    <message>
        <source>Unable to locate enough funds for this transaction that are not equal 1000 DNET.</source>
        <translation>Für diese Transaktion konnten nicht genug Beträge gefunden werden, die ungleich 1000 DNET sind.</translation>
    </message>
    <message>
        <source>Use separate SOCKS5 proxy to reach peers via Tor hidden services (default: %s)</source>
        <translation>Separaten SOCKS5-Proxy verwenden, um Gegenstellen über versteckte Tor-Dienste zu erreichen (Standard: %s)</translation>
    </message>
    <message>
        <source>Warning: -maxtxfee is set very high! Fees this large could be paid on a single transaction.</source>
        <translation>Warnung: -maxtxfee ist auf einen sehr hohen Wert gesetzt! Diese Gebühr könnte schon beim Senden einer einzelnen Transaktion fällig werden.</translation>
    </message>
    <message>
        <source>Warning: Please check that your computer's date and time are correct! If your clock is wrong Paycore Core will not work properly.</source>
        <translation>Warnung: Bitte überprüfen Sie die Datums- und Uhrzeiteinstellungen ihres Computers, da Paycore Core ansonsten nicht ordnungsgemäß funktionieren wird!</translation>
    </message>
    <message>
        <source>Whitelist peers connecting from the given netmask or IP address. Can be specified multiple times.</source>
        <translation>Erlaube Gegenstellen mit dieser Netzmaske oder IP-Adresse. Diese Option kann mehrmals eingetragen werden.</translation>
    </message>
    <message>
        <source>Whitelisted peers cannot be DoS banned and their transactions are always relayed, even if they are already in the mempool, useful e.g. for a gateway</source>
        <translation>Erlaubte Gegenstellen können nicht wegen DoS ausgeschlossen werden und ihre Transaktionen werden immer weitergeleitet, sogar wenn sie schon im Memory-Pool sind. Dies ist z.B. für Gateways nützlich.</translation>
    </message>
    <message>
        <source>(25791 could be used only on mainnet)</source>
        <translation>(25791 kann nur im Standardnetz benutzt werden)</translation>
    </message>
    <message>
        <source>(default: %s)</source>
        <translation>(Standard: %s)</translation>
    </message>
    <message>
        <source>&lt;category&gt; can be:
</source>
        <translation>&lt;category&gt; kann sein:
</translation>
    </message>
    <message>
        <source>Accept public REST requests (default: %u)</source>
        <translation>Akzeptiere öffentliche REST-Anforderungen (Standard: %u)</translation>
    </message>
    <message>
        <source>Acceptable ciphers (default: %s)</source>
        <translation>Akzeptierte Verschlüsselungen (Standard: %s) </translation>
    </message>
    <message>
        <source>Always query for peer addresses via DNS lookup (default: %u)</source>
        <translation>Peer-Adressen immer über DNS abfragen (Standard: %u)</translation>
    </message>
    <message>
        <source>Cannot resolve -whitebind address: '%s'</source>
        <translation>Kann Adresse via -whitebind nicht auflösen: '%s'</translation>
    </message>
    <message>
        <source>Connect through SOCKS5 proxy</source>
        <translation>Über einen SOCKS5-Proxy verbinden</translation>
    </message>
    <message>
        <source>Connect to KeePassHttp on port &lt;port&gt; (default: %u)</source>
        <translation>Mit KeePassHttp auf &lt;port&gt; verbinden (Standard: %u)</translation>
    </message>
    <message>
        <source>Copyright (C) 2009-%i The Bitcoin Core Developers</source>
        <translation>Copyright (C) 2009-%i Die "Bitcoin Core"-Entwickler</translation>
    </message>
    <message>
        <source>Copyright (C) 2014-%i The Paycore Core Developers</source>
        <translation>Copyright (C) 2014-%i Die "Paycore Core"-Entwickler</translation>
    </message>
    <message>
        <source>Could not parse -rpcbind value %s as network address</source>
        <translation>-rpcbind Wert %s konnte nicht als Netzwerkadresse erkannt werden</translation>
    </message>
    <message>
        <source>Obfuscate is idle.</source>
        <translation>Obfuscate ist untätig.</translation>
    </message>
    <message>
        <source>Obfuscate request complete:</source>
        <translation>Obfuscate-Anfrage vollständig:</translation>
    </message>
    <message>
        <source>Obfuscate request incomplete:</source>
        <translation>Obfuscate-Anfrage unvollständig:</translation>
    </message>
    <message>
        <source>Disable safemode, override a real safe mode event (default: %u)</source>
        <translation>Sicherheitsmodus deaktivieren, überschreibt ein echtes Sicherheitsmodusereignis (Standard: %u)</translation>
    </message>
    <message>
        <source>Enable the client to act as a masternode (0-1, default: %u)</source>
        <translation>Masternode-Modus aktivieren. (0=aus, 1=an; Voreinstellung: %u)</translation>
    </message>
    <message>
        <source>Error connecting to Masternode.</source>
        <translation>Fehler bei der Verbindung zum Masternode.</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet requires newer version of Paycore Core</source>
        <translation>Fehler beim Laden von wallet.dat: Wallet benötigt neuere Version von Paycore Core</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occured, see debug.log for details</source>
        <translation>Fehler: ein interner Fehler ist aufgetreten, Details sind in der Datei debug.log</translation>
    </message>
    <message>
        <source>Error: Can't select current denominated inputs</source>
        <translation>Fehler: die aktuell gestückelten Inputs können nicht ausgewählt werden</translation>
    </message>
    <message>
        <source>Error: Unsupported argument -tor found, use -onion.</source>
        <translation>Fehler: Paramter -tor wird nicht unterstützt, bitte -onion benutzen.</translation>
    </message>
    <message>
        <source>Fee (in DNET/kB) to add to transactions you send (default: %s)</source>
        <translation>Gebühren (in DNET pro Kb), die gesendeten Transaktionen hinzugefügt werden (Standard: %s)</translation>
    </message>
    <message>
        <source>Finalizing transaction.</source>
        <translation>Füge Transaktion zusammen.</translation>
    </message>
    <message>
        <source>Force safe mode (default: %u)</source>
        <translation>Sicherheitsmodus erzwingen (Standard: %u)</translation>
    </message>
    <message>
        <source>Found enough users, signing ( waiting %s )</source>
        <translation>Genug Partner gefunden, signiere ( warte %s )</translation>
    </message>
    <message>
        <source>Found enough users, signing ...</source>
        <translation>Genug Partner gefunden, signiere ... </translation>
    </message>
    <message>
        <source>Generate coins (default: %u)</source>
        <translation>Coins erzeugen (Standard: %u)</translation>
    </message>
    <message>
        <source>How many blocks to check at startup (default: %u, 0 = all)</source>
        <translation>Wieviele Blöcke beim Starten geprüft werden sollen (Standard: %u, 0 = alle)</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Importiere...</translation>
    </message>
    <message>
        <source>Imports blocks from external blk000??.dat file</source>
        <translation>Blöcke aus externer Datei blk000??.dat importieren</translation>
    </message>
    <message>
        <source>Include IP addresses in debug output (default: %u)</source>
        <translation>IP-Adressen in die Debug-Ausgabe mit aufnehmen (Standard: %u)</translation>
    </message>
    <message>
        <source>Incompatible mode.</source>
        <translation>Inkompatibler Modus.</translation>
    </message>
    <message>
        <source>Incompatible version.</source>
        <translation>Inkompatible Version.</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Fehlerhafter oder kein Genesis-Block gefunden. Falsches Datenverzeichnis für das Netzwerk?</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Hinweis</translation>
    </message>
    <message>
        <source>Initialization sanity check failed. Paycore Core is shutting down.</source>
        <translation>Fehler beim Initialisieren (Plausibilitätsprüfung fehlgeschlagen).
Paycore Core wird heruntergefahren.</translation>
    </message>
    <message>
        <source>Input is not valid.</source>
        <translation>Eintrag ist nicht gültig.</translation>
    </message>
    <message>
        <source>InstantX options:</source>
        <translation>InstantX Optionen:</translation>
    </message>
    <message>
        <source>Insufficient funds.</source>
        <translation>Unzureichender Kontostand.</translation>
    </message>
    <message>
        <source>Invalid -onion address: '%s'</source>
        <translation>Ungültige "-onion"-Adresse: '%s'</translation>
    </message>
    <message>
        <source>Invalid -proxy address: '%s'</source>
        <translation>Ungültige Adresse in -proxy: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -maxtxfee=&lt;amount&gt;: '%s'</source>
        <translation>Ungültiger Betrag für -maxtxfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -minrelaytxfee=&lt;amount&gt;: '%s'</source>
        <translation>Ungültiger Betrag für -minrelaytxfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -mintxfee=&lt;amount&gt;: '%s'</source>
        <translation>Ungültiger Betrag für -mintxfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s' (must be at least %s)</source>
        <translation>Ungültiger Betrag für -paytxfee=&lt;amount&gt;: '%s' (Betrag muss mindestens %s sein)</translation>
    </message>
    <message>
        <source>Invalid amount for -paytxfee=&lt;amount&gt;: '%s'</source>
        <translation>Ungültiger Betrag für -paytxfee=&lt;amount&gt;: '%s'</translation>
    </message>
    <message>
        <source>Last successful Obfuscate action was too recent.</source>
        <translation>Die letzte erfolgreiche Obfuscate-Transaktion ist noch zu neu.</translation>
    </message>
    <message>
        <source>Limit size of signature cache to &lt;n&gt; entries (default: %u)</source>
        <translation>Größe des Signaturcaches auf &lt;n&gt; Einträge begrenzen (Standard: %u)</translation>
    </message>
    <message>
        <source>Listen for JSON-RPC connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>&lt;port&gt;nach JSON-RPC-Verbindungen abhören (Standard: %u oder Testnetz: %u)</translation>
    </message>
    <message>
        <source>Listen for connections on &lt;port&gt; (default: %u or testnet: %u)</source>
        <translation>&lt;port&gt; nach Verbindungen abhören (Standard: %u oder Testnetz: %u)</translation>
    </message>
    <message>
        <source>Loading budget cache...</source>
        <translation>Lade Budget-Cache...</translation>
    </message>
    <message>
        <source>Loading masternode cache...</source>
        <translation>Lade Masternode-Cache...</translation>
    </message>
    <message>
        <source>Loading masternode payment cache...</source>
        <translation>Lade Masternode Zahlungs-Cache...</translation>
    </message>
    <message>
        <source>Lock is already in place.</source>
        <translation>Schon gesperrt.</translation>
    </message>
    <message>
        <source>Lock masternodes from masternode configuration file (default: %u)</source>
        <translation>Masternodes über Masternode-Konfiguration sperren (Standard: %u)</translation>
    </message>
    <message>
        <source>Maintain at most &lt;n&gt; connections to peers (default: %u)</source>
        <translation>Maximal &lt;n&gt; Verbindungen zu Gegenstellen aufrechterhalten (Standard: %u)</translation>
    </message>
    <message>
        <source>Maximum per-connection receive buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maximale Größe des Empfangspuffers pro Verbindung, &lt;n&gt; * 1000 Byte (Standard: %u)</translation>
    </message>
    <message>
        <source>Maximum per-connection send buffer, &lt;n&gt;*1000 bytes (default: %u)</source>
        <translation>Maximale Größe des Sendepuffers pro Verbindung, &lt;n&gt; * 1000 Byte (Standard: %u)</translation>
    </message>
    <message>
        <source>Mixing in progress...</source>
        <translation>Am Mixen...</translation>
    </message>
    <message>
        <source>Need to specify a port with -whitebind: '%s'</source>
        <translation>Für -whitebind muss eine Portnummer angegeben werden: '%s'</translation>
    </message>
    <message>
        <source>No Masternodes detected.</source>
        <translation>Keine Masternodes gefunden.</translation>
    </message>
    <message>
        <source>No compatible Masternode found.</source>
        <translation>Kein kompatibler Masternode gefunden.</translation>
    </message>
    <message>
        <source>Not in the Masternode list.</source>
        <translation>Nicht in der Masternode-Liste.</translation>
    </message>
    <message>
        <source>Number of automatic wallet backups (default: 10)</source>
        <translation>Anzahl automatischer Wallet-Sicherungskopien (Standard: 10)</translation>
    </message>
    <message>
        <source>Only accept block chain matching built-in checkpoints (default: %u)</source>
        <translation>Blockkette nur als gültig ansehen, wenn sie mit den integrierten Prüfpunkten übereinstimmt (Standard: %u)</translation>
    </message>
    <message>
        <source>Only connect to nodes in network &lt;net&gt; (ipv4, ipv6 or onion)</source>
        <translation>Verbinde nur zu Knoten des Netztyps &lt;net&gt; (ipv4, ipv6 oder onion)</translation>
    </message>
    <message>
        <source>Prepend debug output with timestamp (default: %u)</source>
        <translation>Debugausgaben einen Zeitstempel voranstellen (Standard: %u)</translation>
    </message>
    <message>
        <source>Run a thread to flush wallet periodically (default: %u)</source>
        <translation>Einen Thread starten, der periodisch die Wallet auf den Datenträger sichert (Standard: %u)</translation>
    </message>
    <message>
        <source>Send trace/debug info to debug.log file (default: %u)</source>
        <translation>Rückverfolgungs- und Debuginformationen in debug.log schreiben (Standard: %u)</translation>
    </message>
    <message>
        <source>Send transactions as zero-fee transactions if possible (default: %u)</source>
        <translation>Wenn möglich als gebührenfreie Transaktion versenden (Standard: %u)</translation>
    </message>
    <message>
        <source>Server certificate file (default: %s)</source>
        <translation>Datei mit Serverzertifikat (Standard: %s)</translation>
    </message>
    <message>
        <source>Server private key (default: %s)</source>
        <translation>Privater Serverschlüssel (Standard: %s)</translation>
    </message>
    <message>
        <source>Set external address:port to get to this masternode (example: %s)</source>
        <translation>Setze externe Adresse und Port, um diesen Masternode zu erreichen (Beispiel: %s)</translation>
    </message>
    <message>
        <source>Set key pool size to &lt;n&gt; (default: %u)</source>
        <translation>Größe des Schlüsselpools festlegen auf &lt;n&gt; (Standard: %u)</translation>
    </message>
    <message>
        <source>Set minimum block size in bytes (default: %u)</source>
        <translation>Minimale Blockgröße in Bytes festlegen (Standard: %u)</translation>
    </message>
    <message>
        <source>Set the number of threads to service RPC calls (default: %d)</source>
        <translation>Maximale Anzahl an Threads zur Verarbeitung von RPC-Anfragen festlegen (Standard: %d)</translation>
    </message>
    <message>
        <source>Sets the DB_PRIVATE flag in the wallet db environment (default: %u)</source>
        <translation>DB_PRIVATE-Flag in der Wallet-Datenbankumgebung setzen (Standard: %u)</translation>
    </message>
    <message>
        <source>Signing timed out.</source>
        <translation>Zeitüberschreitung der Signierung.</translation>
    </message>
    <message>
        <source>Specify configuration file (default: %s)</source>
        <translation>Konfigurationsdatei festlegen (Standard: %s)</translation>
    </message>
    <message>
        <source>Specify connection timeout in milliseconds (minimum: 1, default: %d)</source>
        <translation>Verbindungzeitüberschreitung in Millisekunden festlegen (Minimum: 1, Standard: %d)</translation>
    </message>
    <message>
        <source>Specify masternode configuration file (default: %s)</source>
        <translation>Konfigurationsdatei der Masternode-Einstellungen angeben (Standard: %s)</translation>
    </message>
    <message>
        <source>Specify pid file (default: %s)</source>
        <translation>pid-Datei angeben (Standard: %s)</translation>
    </message>
    <message>
        <source>Spend unconfirmed change when sending transactions (default: %u)</source>
        <translation>Unbestätigtes Wechselgeld beim Senden von Transaktionen ausgeben (Standard: %u)</translation>
    </message>
    <message>
        <source>Stop running after importing blocks from disk (default: %u)</source>
        <translation>Nach dem Import von Blöcken von der Festplatte Programm beenden (Standard: %u)</translation>
    </message>
    <message>
        <source>Submitted following entries to masternode: %u / %d</source>
        <translation>Folgende Einträge wurden an Masternode gesendet: %u / %d</translation>
    </message>
    <message>
        <source>Submitted to masternode, waiting for more entries ( %u / %d ) %s</source>
        <translation>An Masternode gesendet, warte auf weitere Einträge ( %u / %d ) %s</translation>
    </message>
    <message>
        <source>Submitted to masternode, waiting in queue %s</source>
        <translation>An Masternode übermittelt, wartet in Warteschlange %s</translation>
    </message>
    <message>
        <source>Synchronization failed</source>
        <translation>Synchronisation fehlgeschlagen</translation>
    </message>
    <message>
        <source>Synchronization finished</source>
        <translation>Synchronisation beendet</translation>
    </message>
    <message>
        <source>Synchronizing budgets...</source>
        <translation>Synchronisiere Budgets...</translation>
    </message>
    <message>
        <source>Synchronizing masternode winners...</source>
        <translation>Synchronisiere Masternode Gewinner...</translation>
    </message>
    <message>
        <source>Synchronizing masternodes...</source>
        <translation>Synchronisiere Masternodes...</translation>
    </message>
    <message>
        <source>Synchronizing sporks...</source>
        <translation>Synchronisiere Sporks...</translation>
    </message>
    <message>
        <source>This is not a Masternode.</source>
        <translation>Dies ist kein Masternode.</translation>
    </message>
    <message>
        <source>Threshold for disconnecting misbehaving peers (default: %u)</source>
        <translation>Schwellenwert, um Verbindungen zu sich nicht konform verhaltenden Gegenstellen zu beenden (Standard: %u)</translation>
    </message>
    <message>
        <source>Use KeePass 2 integration using KeePassHttp plugin (default: %u)</source>
        <translation>"KeePass 2"-Integration mit KeePassHttp-plugin (Standard: %u)</translation>
    </message>
    <message>
        <source>Use N separate masternodes to anonymize funds  (2-8, default: %u)</source>
        <translation>N unterschiedliche Masternodes benutzen, um PCR zu anonymisieren (2-8, Standard: %u)</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: %u)</source>
        <translation>UPnP verwenden, um eine Portweiterleitung einzurichten (Standard: %u)</translation>
    </message>
    <message>
        <source>Wallet needed to be rewritten: restart Paycore Core to complete</source>
        <translation>Die Wallet musste neu geschrieben werden. Bitte das Programm neu starten um den Vorgang abzuschließen</translation>
    </message>
    <message>
        <source>Warning: Unsupported argument -benchmark ignored, use -debug=bench.</source>
        <translation>Warnung: Veraltetes Argument -benchmark wird ignoriert, bitte -debug=bench verwenden.</translation>
    </message>
    <message>
        <source>Warning: Unsupported argument -debugnet ignored, use -debug=net.</source>
        <translation>Warnung: Veraltetes Argument -debugnet wird ignoriert, bitte -debug=net verwenden.</translation>
    </message>
    <message>
        <source>Will retry...</source>
        <translation>Versuche erneut...</translation>
    </message>
    <message>
        <source>Invalid masternodeprivkey. Please see documenation.</source>
        <translation>Masternode-Geheimschlüssel (masternodeprivkey) ist ungültig. Siehe Dokumentation. </translation>
    </message>
    <message>
        <source>(must be25791 for mainnet)</source>
        <translation>(muss für Standardnetz25791 sein)</translation>
    </message>
    <message>
        <source>Can't find random Masternode.</source>
        <translation>Kann keinen zufällig ausgewählten Masternode finden</translation>
    </message>
    <message>
        <source>Can't mix while sync in progress.</source>
        <translation>Währen der Synchronisierung kann nicht gemixt werden.</translation>
    </message>
    <message>
        <source>Could not parse masternode.conf</source>
        <translation>masternode.conf konnte nicht analysiert werden</translation>
    </message>
    <message>
        <source>Invalid netmask specified in -whitelist: '%s'</source>
        <translation>Ungültige Netzmaske für -whitelist angegeben: '%s'</translation>
    </message>
    <message>
        <source>Invalid port detected in masternode.conf</source>
        <translation>Ungültige Portnummer in masternode.conf</translation>
    </message>
    <message>
        <source>Invalid private key.</source>
        <translation>Fehlerhafter privater Schlüssel.</translation>
    </message>
    <message>
        <source>Invalid script detected.</source>
        <translation>Invalides Zahlskript entdeckt.</translation>
    </message>
    <message>
        <source>KeePassHttp id for the established association</source>
        <translation>"KeePassHttp id" für bestehende verknüpfte Verbindungen.</translation>
    </message>
    <message>
        <source>KeePassHttp key for AES encrypted communication with KeePass</source>
        <translation>"KeePassHttp key" für die  AES-verschlüsselte Kommunikation mit "KeePass"</translation>
    </message>
    <message>
        <source>Keep N DNET anonymized (default: %u)</source>
        <translation>Betrag welcher anonymisiert vorgehalten wird. (Voreinstellung: %u)</translation>
    </message>
    <message>
        <source>Keep at most &lt;n&gt; unconnectable transactions in memory (default: %u)</source>
        <translation>Maximal &lt;n&gt; (noch) nicht einsortierte Zahlungen zwischenspeichern (Voreinstellung: %u)</translation>
    </message>
    <message>
        <source>Last Obfuscate was too recent.</source>
        <translation>Letzte Obfuscate-Transaktion ist noch zu neu.</translation>
    </message>
    <message>
        <source>Line: %d</source>
        <translation>Zeile: %d</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Lade Adressen...</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Lade Blockindex...</translation>
    </message>
    <message>
        <source>Loading wallet... (%3.2f %%)</source>
        <translation>Lade Wallet... (%3.2f %%)</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Lade Wallet...</translation>
    </message>
    <message>
        <source>Masternode options:</source>
        <translation>Masternode Optionen:</translation>
    </message>
    <message>
        <source>Masternode queue is full.</source>
        <translation>Warteschlange der Masternode ist voll.</translation>
    </message>
    <message>
        <source>Masternode:</source>
        <translation>Masternode:</translation>
    </message>
    <message>
        <source>Missing input transaction information.</source>
        <translation>Fehlende Informationen zur Eingangs-Transaktion.</translation>
    </message>
    <message>
        <source>No funds detected in need of denominating.</source>
        <translation>Kein Kapital gefunden, dass zerstückelt werden muss.</translation>
    </message>
    <message>
        <source>No matching denominations found for mixing.</source>
        <translation>Keine passende Zerstückelungen zum Mixen gefunden.</translation>
    </message>
    <message>
        <source>Node relay options:</source>
        <translation>Vermittlungs-Optionen für Knoten:</translation>
    </message>
    <message>
        <source>Non-standard public key detected.</source>
        <translation>nicht Standard öffentlicher Schlüssel erkannt.</translation>
    </message>
    <message>
        <source>Not compatible with existing transactions.</source>
        <translation>Nicht kompatibel mit existierenden Transaktionen.</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Nicht genügend Datei-Deskriptoren verfügbar.</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Optionen:</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Passwort für JSON-RPC-Verbindungen</translation>
    </message>
    <message>
        <source>RPC SSL options: (see the Bitcoin Wiki for SSL setup instructions)</source>
        <translation>RPC SSL Optionen: (siehe Bitcoin Wiki für eine Installationsanleitung)</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>RPC-Serveroptionen:</translation>
    </message>
    <message>
        <source>RPC support for HTTP persistent connections (default: %d)</source>
        <translation>RPC-Unterstützung für persistente HTTP-Verbindungen (default: %d)</translation>
    </message>
    <message>
        <source>Randomly drop 1 of every &lt;n&gt; network messages</source>
        <translation>Zufällig eine von &lt;n&gt; Netzwerknachrichten verwerfen</translation>
    </message>
    <message>
        <source>Randomly fuzz 1 of every &lt;n&gt; network messages</source>
        <translation>Zufällig eine von &lt;n&gt; Netzwerknachrichten verwürfeln</translation>
    </message>
    <message>
        <source>Rebuild block chain index from current blk000??.dat files</source>
        <translation>Blockkettenindex aus aktuellen Dateien blk000??.dat wieder aufbauen</translation>
    </message>
    <message>
        <source>Receive and display P2P network alerts (default: %u)</source>
        <translation>P2P Netzwerk-Alarme empfangen und anzeigen (Standard: %u)</translation>
    </message>
    <message>
        <source>Relay and mine data carrier transactions (default: %u)</source>
        <translation>"Data Carrier"-Transaktionen weiterleiten (Standard: %u)</translation>
    </message>
    <message>
        <source>Relay non-P2SH multisig (default: %u)</source>
        <translation>Nicht-P2SH-Multisig weiterleiten (Standard: %u)</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Blockkette erneut nach fehlenden Wallet-Transaktionen durchsuchen</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Durchsuche erneut...</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Als Hintergrunddienst ausführen und Befehle annehmen</translation>
    </message>
    <message>
        <source>Session not complete!</source>
        <translation>Sitzung ist nicht vollständig!</translation>
    </message>
    <message>
        <source>Session timed out.</source>
        <translation>Zeitüberschreitung der Sitzung.</translation>
    </message>
    <message>
        <source>Set database cache size in megabytes (%d to %d, default: %d)</source>
        <translation>Größe des Datenbankcaches in Megabyte festlegen (%d bis %d, Standard: %d)</translation>
    </message>
    <message>
        <source>Set maximum block size in bytes (default: %d)</source>
        <translation>Maximale Blockgröße in Byte festlegen (Standard: %d)</translation>
    </message>
    <message>
        <source>Set the masternode private key</source>
        <translation>Privaten Masternode-Schlüssel setzen</translation>
    </message>
    <message>
        <source>Show all debugging options (usage: --help -help-debug)</source>
        <translation>Zeige alle Debuggingoptionen (Benutzung: --help -help-debug)</translation>
    </message>
    <message>
        <source>Shrink debug.log file on client startup (default: 1 when no -debug)</source>
        <translation>Protokolldatei debug.log beim Starten des Clients kürzen (Standard: 1, wenn kein -debug)</translation>
    </message>
    <message>
        <source>Signing failed.</source>
        <translation>Signierung fehlgeschalgen.</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Signierung der Transaktion fehlgeschlagen</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Datenverzeichnis festlegen</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Wallet-Datei angeben (innerhalb des Datenverzeichnisses)</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Die eigene öffentliche Adresse angeben</translation>
    </message>
    <message>
        <source>Synchronization pending...</source>
        <translation>Synchronisation steht bevor...</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>Dieser Hilfetext</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>Dies ist experimentelle Software.</translation>
    </message>
    <message>
        <source>This is intended for regression testing tools and app development.</source>
        <translation>Dies ist für Regressionstest-Tools und Anwendungsentwicklung gedacht.</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Transaktionsbetrag zu niedrig</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>Transaktionsbeträge müssen positiv sein</translation>
    </message>
    <message>
        <source>Transaction created successfully.</source>
        <translation>Transaktion erfolgreich erstellt.</translation>
    </message>
    <message>
        <source>Transaction fees are too high.</source>
        <translation>Transaktionsgebühren sind zu hoch.</translation>
    </message>
    <message>
        <source>Transaction not valid.</source>
        <translation>Transaktion ungültig.</translation>
    </message>
    <message>
        <source>Transaction too large for fee policy</source>
        <translation>Transaktion ist für die Gebührenrichtlinie zu groß</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Transaktion zu groß</translation>
    </message>
    <message>
        <source>Transmitting final transaction.</source>
        <translation>Übertrage fertige Transaktion.</translation>
    </message>
    <message>
        <source>Unable to bind to %s on this computer (bind returned error %s)</source>
        <translation>Kann auf diesem Computer nicht an %s binden (von bind zurückgegebener Fehler: %s)</translation>
    </message>
    <message>
        <source>Unable to sign spork message, wrong key?</source>
        <translation>Die Spork-Nachricht konnte nicht signiert werden. Wurde der Key falsch gesetzt?</translation>
    </message>
    <message>
        <source>Unknown network specified in -onlynet: '%s'</source>
        <translation>Unbekannter Netztyp in -onlynet angegeben: '%s'</translation>
    </message>
    <message>
        <source>Unknown state: id = %u</source>
        <translation>Unbekannter Status: id = %u</translation>
    </message>
    <message>
        <source>Upgrade wallet to latest format</source>
        <translation>Wallet auf das neueste Format aktualisieren</translation>
    </message>
    <message>
        <source>Use OpenSSL (https) for JSON-RPC connections</source>
        <translation>OpenSSL (https) für JSON-RPC-Verbindungen verwenden</translation>
    </message>
    <message>
        <source>Use UPnP to map the listening port (default: 1 when listening)</source>
        <translation>UPnP verwenden, um eine Portweiterleitung einzurichten (Standard: 1, wenn abgehört wird)</translation>
    </message>
    <message>
        <source>Use the test network</source>
        <translation>Das Testnetz verwenden</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Benutzername für JSON-RPC-Verbindungen</translation>
    </message>
    <message>
        <source>Value more than Obfuscate pool maximum allows.</source>
        <translation>Wert größer als der vom Obfuscate Pool maximal erlaubte.</translation>
    </message>
    <message>
        <source>Verifying blocks...</source>
        <translation>Verifiziere Blöcke...</translation>
    </message>
    <message>
        <source>Verifying wallet...</source>
        <translation>Verifiziere Wallet...</translation>
    </message>
    <message>
        <source>Wallet %s resides outside data directory %s</source>
        <translation>Wallet %s liegt außerhalb des Datenverzeichnisses %s</translation>
    </message>
    <message>
        <source>Wallet is locked.</source>
        <translation>Wallet gesperrt.</translation>
    </message>
    <message>
        <source>Wallet options:</source>
        <translation>Wallet-Optionen:</translation>
    </message>
    <message>
        <source>Wallet window title</source>
        <translation>Fensterüberschrift des Wallet</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Warnung</translation>
    </message>
    <message>
        <source>Warning: This version is obsolete, upgrade required!</source>
        <translation>Warnung: Diese Version is veraltet, Aktualisierung erforderlich!</translation>
    </message>
    <message>
        <source>You need to rebuild the database using -reindex to change -txindex</source>
        <translation>Sie müssen die Datenbank mit Hilfe von -reindex neu aufbauen, um -txindex zu verändern</translation>
    </message>
    <message>
        <source>Your entries added successfully.</source>
        <translation>Ihre Einträge wurden erfolgreich hinzugefügt.</translation>
    </message>
    <message>
        <source>Your transaction was accepted into the pool!</source>
        <translation>Ihre Transaktion wurde im Pool akzeptiert!</translation>
    </message>
    <message>
        <source>Zapping all transactions from wallet...</source>
        <translation>Lösche alle Transaktionen aus Wallet...</translation>
    </message>
    <message>
        <source>on startup</source>
        <translation>beim Starten</translation>
    </message>
    <message>
        <source>wallet.dat corrupt, salvage failed</source>
        <translation>wallet.dat beschädigt, Datenrettung fehlgeschlagen</translation>
    </message>
</context>
</TS>